# GPT-SoVITS API 使用文档

## 📋 目录

1. [API 基本信息](#api-基本信息)
2. [调用方法](#调用方法)
3. [参数说明](#参数说明)
4. [快速部署](#快速部署)
5. [常见问题](#常见问题)

---

## API 基本信息

### 服务器配置

| 项目 | 值 |
|------|-----|
| **API Base URL** | `http://192.168.31.177:9880/tts` |
| **API 类型** | GPT-SoVITS v4 |
| **Build 版本** | GPT-SoVITS-v4-20250422fix |

### 角色配置：可莉 (Klee)

#### 参考音频信息

| 项目 | 值 |
|------|-----|
| **文件路径** | `F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav` |
| **对应文本** | `买东西那天也有一个人帮了开了款式，那个人好像叫` |
| **语言** | zh (中文) |

#### 模型文件路径

| 项目 | 值 |
|------|-----|
| **GPT 模型** | `F:\GPT-SoVITS\GPT-SoVITS-v4-20250422fix\GPT_weights_v2\可莉-e10.ckpt` |
| **SoVITS 模型** | `F:\GPT-SoVITS\GPT-SoVITS-v4-20250422fix\SoVITS_weights_v2\可莉_e25_s3025.pth` |

---

## 调用方法

### 方法一：使用 curl 命令（推荐）

#### 基本调用

```bash
curl -X POST "http://192.168.31.177:9880/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "output_dir": "tmp/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output output.wav
```

#### 带自定义输出目录

```bash
# 创建输出目录
mkdir -p /home/terrence/Desktop/openclaw/generated_audio

# 调用API并保存到指定目录
curl -X POST "http://192.168.31.177:9880/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "output_dir": "/home/terrence/Desktop/openclaw/generated_audio/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output /home/terrence/Desktop/openclaw/generated_audio/klee_hello.wav
```

---

### 方法二：使用 Python requests

#### 基本示例

```python
import requests

# API 配置
API_URL = "http://192.168.31.177:9880/tts"

# 请求参数
payload = {
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "output_dir": "tmp/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
}

# 发送请求
response = requests.post(API_URL, json=payload)

# 检查请求是否成功
if response.status_code == 200:
    # 保存音频文件
    with open("output.wav", "wb") as f:
        f.write(response.content)
    print("✅ 音频生成成功！")
else:
    print(f"❌ 生成失败: {response.status_code}")
    print(response.text)
```

#### 通用函数封装

```python
import requests
import os
from datetime import datetime

def generate_klee_voice(text, output_dir="generated_audio", speed_factor=1.0):
    """
    生成可莉的语音

    Args:
        text (str): 要合成的文本
        output_dir (str): 输出目录
        speed_factor (float): 语速调整 (0.5-2.0)

    Returns:
        str: 生成的音频文件路径
    """
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # API 配置
    API_URL = "http://192.168.31.177:9880/tts"

    # 请求参数
    payload = {
        "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
        "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
        "prompt_lang": "zh",
        "text": text,
        "text_lang": "auto",
        "output_dir": output_dir,
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "text_split_method": "cut4",
        "batch_size": 1,
        "speed_factor": speed_factor
    }

    # 发送请求
    response = requests.post(API_URL, json=payload)

    # 检查请求是否成功
    if response.status_code == 200:
        # 生成文件名（使用时间戳）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"klee_{timestamp}.wav"
        output_path = os.path.join(output_dir, filename)

        # 保存音频文件
        with open(output_path, "wb") as f:
            f.write(response.content)

        print(f"✅ 音频生成成功！保存到: {output_path}")
        return output_path
    else:
        print(f"❌ 生成失败: {response.status_code}")
        print(response.text)
        return None

# 使用示例
if __name__ == "__main__":
    voice = generate_klee_voice("你好，我是可莉！很高兴为你服务。")
```

---

### 方法三：使用 Node.js (axios)

#### 基本示例

```javascript
const axios = require('axios');
const fs = require('fs');

// API 配置
const API_URL = 'http://192.168.31.177:9880/tts';

// 请求参数
const payload = {
    ref_audio_path: 'F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav',
    prompt_text: '买东西那天也有一个人帮了开了款式，那个人好像叫',
    prompt_lang: 'zh',
    text: '你好，我是可莉！很高兴为你服务。',
    text_lang: 'auto',
    output_dir: 'tmp/',
    top_k: 5,
    top_p: 1,
    temperature: 1,
    text_split_method: 'cut4',
    batch_size: 1,
    speed_factor: 1.0
};

// 发送请求
axios.post(API_URL, payload, { responseType: 'arraybuffer' })
    .then(response => {
        // 保存音频文件
        fs.writeFileSync('output.wav', response.data);
        console.log('✅ 音频生成成功！');
    })
    .catch(error => {
        console.error('❌ 生成失败:', error.message);
    });
```

#### 通用函数封装

```javascript
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// API 配置
const API_URL = 'http://192.168.31.177:9880/tts';

/**
 * 生成可莉的语音
 * @param {string} text - 要合成的文本
 * @param {string} outputDir - 输出目录
 * @param {number} speedFactor - 语速调整 (0.5-2.0)
 * @returns {Promise<string>} 生成的音频文件路径
 */
async function generateKleeVoice(text, outputDir = 'generated_audio', speedFactor = 1.0) {
    // 创建输出目录
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // 请求参数
    const payload = {
        ref_audio_path: 'F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav',
        prompt_text: '买东西那天也有一个人帮了开了款式，那个人好像叫',
        prompt_lang: 'zh',
        text: text,
        text_lang: 'auto',
        output_dir: outputDir,
        top_k: 5,
        top_p: 1,
        temperature: 1,
        text_split_method: 'cut4',
        batch_size: 1,
        speed_factor: speedFactor
    };

    try {
        // 发送请求
        const response = await axios.post(API_URL, payload, {
            responseType: 'arraybuffer',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // 生成文件名（使用UUID）
        const filename = `klee_${uuidv4()}.wav`;
        const outputPath = path.join(outputDir, filename);

        // 保存音频文件
        fs.writeFileSync(outputPath, response.data);

        console.log(`✅ 音频生成成功！保存到: ${outputPath}`);
        return outputPath;
    } catch (error) {
        console.error('❌ 生成失败:', error.message);
        throw error;
    }
}

// 使用示例
(async () => {
    try {
        const voicePath = await generateKleeVoice('你好，我是可莉！很高兴为你服务。');
        console.log(`生成的音频文件: ${voicePath}`);
    } catch (error) {
        console.error('执行失败:', error);
    }
})();
```

---

## 参数说明

### 必需参数

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `ref_audio_path` | string | 参考音频文件路径（必需） | `F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav` |
| `prompt_text` | string | 参考音频对应的文本内容（必需） | `买东西那天也有一个人帮了开了款式，那个人好像叫` |
| `prompt_lang` | string | 参考音频语言（zh/en/ja等） | `zh` |
| `text` | string | 要合成的文本内容（必需） | `你好，我是可莉！` |

### 可选参数

| 参数 | 类型 | 说明 | 默认值 | 范围/建议值 |
|------|------|------|--------|-------------|
| `text_lang` | string | 合成文本语言 | `auto` | `zh`, `en`, `ja` 等 |
| `output_dir` | string | 输出目录路径 | `tmp/` | 任意有效路径 |
| `top_k` | int | Top-K采样参数 | `5` | 1-50 |
| `top_p` | float | Top-P采样参数 | `1` | 0-1 |
| `temperature` | float | 温度参数（控制随机性） | `1` | 0.1-2.0 |
| `text_split_method` | string | 文本分割方法 | `cut4` | `cut4`, `zhengze` 等 |
| `batch_size` | int | 批处理大小 | `1` | 1-8 |
| `speed_factor` | float | 语速调整因子 | `1.0` | 0.5-2.0 |

### 参数调优建议

#### 语速调整 (`speed_factor`)

```bash
# 半速（更慢，更清晰）
speed_factor=0.5

# 正常速度
speed_factor=1.0

# 1.5倍速
speed_factor=1.5

# 2倍速（更快）
speed_factor=2.0
```

#### 随机性调整 (`temperature`)

```bash
# 低随机性（更稳定）
temperature=0.3

# 中等随机性（推荐）
temperature=1.0

# 高随机性（更多变化）
temperature=1.5
```

#### 采样参数 (`top_k`, `top_p`)

```bash
# 精确采样
top_k=1
top_p=0.1

# 标准采样
top_k=5
top_p=1.0

# 宽松采样
top_k=20
top_p=0.95
```

---

## 快速部署

### 1. 创建配置文件

```bash
# 创建配置文件
cat > /home/terrence/Desktop/openclaw/gpt_sovits_config.json << 'EOF'
{
  "api_url": "http://192.168.31.177:9880/tts",
  "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
  "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
  "prompt_lang": "zh",
  "text_lang": "auto",
  "output_dir": "/home/terrence/Desktop/openclaw/generated_audio/",
  "top_k": 5,
  "top_p": 1,
  "temperature": 1,
  "text_split_method": "cut4",
  "batch_size": 1,
  "speed_factor": 1.0
}
EOF
```

### 2. 创建快捷调用脚本

#### Bash 脚本

```bash
#!/bin/bash
# 文件名: generate_klee_voice.sh

# API 配置
API_URL="http://192.168.31.177:9880/tts"
OUTPUT_DIR="/home/terrence/Desktop/openclaw/generated_audio"

# 创建输出目录
mkdir -p "$OUTPUT_DIR"

# 获取命令行参数（要合成的文本）
if [ -z "$1" ]; then
    echo "❌ 请提供要合成的文本"
    echo "用法: ./generate_klee_voice.sh \"你的文本内容\""
    exit 1
fi

TEXT="$1"

# 调用API
curl -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  -d "{
    \"ref_audio_path\": \"F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav\",
    \"prompt_text\": \"买东西那天也有一个人帮了开了款式，那个人好像叫\",
    \"prompt_lang\": \"zh\",
    \"text\": \"$TEXT\",
    \"text_lang\": \"auto\",
    \"output_dir\": \"$OUTPUT_DIR\",
    \"top_k\": 5,
    \"top_p\": 1,
    \"temperature\": 1,
    \"text_split_method\": \"cut4\",
    \"batch_size\": 1,
    \"speed_factor\": 1.0
  }" \
  --output "$OUTPUT_DIR/voice_$(date +%s).wav"

echo "✅ 音频已保存到: $OUTPUT_DIR"
```

**使用方法：**
```bash
# 添加执行权限
chmod +x generate_klee_voice.sh

# 调用生成语音
./generate_klee_voice.sh "你好，我是可莉！很高兴为你服务。"
```

#### Python 脚本

```python
#!/usr/bin/env python3
# 文件名: generate_klee_voice.py

import requests
import os
from datetime import datetime

# API 配置
API_URL = "http://192.168.31.177:9880/tts"
OUTPUT_DIR = "/home/terrence/Desktop/openclaw/generated_audio"
REF_AUDIO_PATH = "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav"
PROMPT_TEXT = "买东西那天也有一个人帮了开了款式，那个人好像叫"

def generate_voice(text):
    """生成可莉的语音"""
    # 创建输出目录
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 请求参数
    payload = {
        "ref_audio_path": REF_AUDIO_PATH,
        "prompt_text": PROMPT_TEXT,
        "prompt_lang": "zh",
        "text": text,
        "text_lang": "auto",
        "output_dir": OUTPUT_DIR,
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "text_split_method": "cut4",
        "batch_size": 1,
        "speed_factor": 1.0
    }

    # 发送请求
    response = requests.post(API_URL, json=payload)

    if response.status_code == 200:
        # 生成文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"voice_{timestamp}.wav"
        output_path = os.path.join(OUTPUT_DIR, filename)

        # 保存音频
        with open(output_path, "wb") as f:
            f.write(response.content)

        print(f"✅ 音频生成成功！保存到: {output_path}")
        return output_path
    else:
        print(f"❌ 生成失败: {response.status_code}")
        print(response.text)
        return None

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
        generate_voice(text)
    else:
        print("❌ 请提供要合成的文本")
        print("用法: python generate_klee_voice.py \"你的文本内容\"")
```

**使用方法：**
```bash
# 添加执行权限
chmod +x generate_klee_voice.py

# 调用生成语音
python generate_klee_voice.py "你好，我是可莉！很高兴为你服务。"
```

---

## 常见问题

### Q1: API 返回错误 "audio/xxx not exists"？

**原因：** 参考音频文件路径不存在或格式不正确

**解决方案：**
```bash
# 1. 检查文件是否存在
ls -l "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav"

# 2. 确认路径格式（Windows 路径使用正斜杠或双反斜杠）
# 正确: "F:/path/to/file.wav" 或 "F:\\path\\to\\file.wav"
```

### Q2: 中文路径导致朗读失败？

**原因：** 编码不一致或路径转义问题

**解决方案：**

1. **使用 UTF-8 编码发送请求**
```python
import json
import requests

payload = {
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！"
}

# 手动序列化 JSON 以确保 UTF-8 编码
json_payload = json.dumps(payload, ensure_ascii=False).encode('utf-8')

response = requests.post(
    "http://192.168.31.177:9880/tts",
    data=json_payload,
    headers={"Content-Type": "application/json; charset=utf-8"}
)
```

2. **使用绝对路径**
```python
# 推荐使用绝对路径
ref_audio_path = "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav"
```

3. **避免路径中的特殊字符**
- 尽量使用简单的文件名
- 避免空格和特殊字符
- 使用英文文件名（如果可能）

### Q3: 如何调整语速？

**方法：** 修改 `speed_factor` 参数

```bash
# 半速（更慢，更清晰）
speed_factor=0.5

# 正常速度（推荐）
speed_factor=1.0

# 1.5倍速
speed_factor=1.5

# 2倍速（更快）
speed_factor=2.0
```

### Q4: 如何改变音色？

**方法：** 使用不同的参考音频文件

```bash
# 1. 准备新的参考音频
# 2. 确保参考音频文本与音频内容匹配
# 3. 修改 prompt_text 参数

curl -X POST "http://192.168.31.177:9880/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/你的新角色.wav",
    "prompt_text": "你的新角色说的文本内容",
    "prompt_lang": "zh",
    "text": "要合成的文本",
    "text_lang": "auto",
    "output_dir": "generated_audio/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output output.wav
```

### Q5: 如何处理长文本？

**方法：** API 会自动分割长文本（默认使用 `cut4` 方法）

```bash
# 超长文本也会自动处理
curl -X POST "http://192.168.31.177:9880/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "这是一个非常非常长的文本，可以包含多句话，API会自动分割并处理...",
    "text_lang": "auto",
    "output_dir": "generated_audio/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output output.wav
```

### Q6: 输出文件在哪里？

**默认输出目录：** `tmp/`（在 API 服务器上）

**自定义输出目录：** 指定 `output_dir` 参数

```bash
# 在共享目录输出
curl -X POST "http://192.168.31.177:9880/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！",
    "text_lang": "auto",
    "output_dir": "/home/terrence/Desktop/openclaw/generated_audio/",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output /home/terrence/Desktop/openclaw/generated_audio/klee.wav
```

### Q7: API 调用超时怎么办？

**原因：** 生成长文本或网络延迟

**解决方案：**
```bash
# 1. 增加超时时间（curl 默认不设置，可能需要调整服务器配置）

# 2. 分段生成长文本

# 3. 检查网络连接
ping 192.168.31.177
```

### Q8: 如何批量生成语音？

**方法：** 使用循环或脚本

```bash
#!/bin/bash
# 批量生成语音

TEXTS=(
    "你好，我是可莉！"
    "今天天气真不错！"
    "我要去冒险了！"
    "你最喜欢什么？"
)

for text in "${TEXTS[@]}"; do
    echo "生成语音: $text"
    curl -X POST "http://192.168.31.177:9880/tts" \
      -H "Content-Type: application/json" \
      -d "{
        \"ref_audio_path\": \"F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav\",
        \"prompt_text\": \"买东西那天也有一个人帮了开了款式，那个人好像叫\",
        \"prompt_lang\": \"zh\",
        \"text\": \"$text\",
        \"text_lang\": \"auto\",
        \"output_dir\": \"/home/terrence/Desktop/openclaw/generated_audio/\",
        \"top_k\": 5,
        \"top_p\": 1,
        \"temperature\": 1,
        \"text_split_method\": \"cut4\",
        \"batch_size\": 1,
        \"speed_factor\": 1.0
      }" \
      --output "/home/terrence/Desktop/openclaw/generated_audio/voice_$(date +%s).wav"
done

echo "✅ 批量生成完成！"
```

---

## 技术支持

### 相关文件位置

- **API 文档：** `/home/terrence/Desktop/openclaw/GPT-SoVITS-API文档.md`
- **自我介绍：** `/home/terrence/Desktop/openclaw/自我介绍.md`
- **长期记忆：** `/home/terrence/.openclaw/workspace/MEMORY.md`

### 部署新 OpenClaw 实例

1. 复制本文档到新工作区
2. 参考文档中的"快速部署"章节
3. 配置 API URL 和参考音频路径
4. 测试调用是否正常

---

## 🚀 使用 GPT-SoVITS 加速服务器

### 加速服务器优势

- **解决中文路径问题**：内置中文路径处理机制，确保参考音频路径正确传输
- **负载均衡**：支持多服务器并发处理，提高生成速度
- **自动故障转移**：当某个服务器不可用时，自动切换到其他服务器
- **统一 API 接口**：与原始 GPT-SoVITS API 完全兼容
- **实时监控**：提供 GUI 界面，实时监控服务器状态

### 如何使用加速服务器处理中文路径

#### 1. 配置加速服务器

1. **启动加速服务器**
   - 运行 `main.py` 启动 GUI 界面
   - 点击"添加服务器"按钮，添加你的 GPT-SoVITS 服务器
   - 配置参考音频路径（支持中文路径）

2. **配置编码设置**
   - 在配置管理中，确保 `encoding_settings` 正确设置：
   ```json
   "encoding_settings": {
     "enable_utf8_encoding": true,
     "force_utf8_for_paths": true,
     "path_encoding": "utf-8",
     "response_encoding": "utf-8"
   }
   ```

#### 2. 调用加速服务器 API

**使用 Python 请求：**

```python
import requests

# 加速服务器地址
url = "http://localhost:9889/tts"

# 请求参数（支持中文路径）
payload = {
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
}

# 发送请求
response = requests.post(url, json=payload)

# 保存音频
if response.status_code == 200:
    with open("output.wav", "wb") as f:
        f.write(response.content)
    print("✅ 音频生成成功！")
else:
    print(f"❌ 生成失败: {response.status_code}")
    print(response.text)
```

**使用 cURL 请求：**

```bash
curl -X POST "http://localhost:9889/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output output.wav
```

### 加速服务器配置示例

**完整配置文件：**

```json
{
  "version": "1.0",
  "server_name": "GPT-SoVITS-Proxy",
  "server_port": 9889,
  "host": "0.0.0.0",
  "servers": [
    {
      "id": 1,
      "name": "可莉服务器",
      "address": "192.168.31.177",
      "port": 9880,
      "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
      "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
      "prompt_lang": "zh",
      "enabled": true,
      "load_balance": "round-robin",
      "max_connections": 10
    }
  ],
  "default_config": {
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  },
  "ui_settings": {
    "theme": "dark",
    "window_width": 1200,
    "window_height": 800,
    "auto_save": true,
    "auto_save_interval": 60,
    "cache_folder": "cache",
    "auto_start_service": false,
    "auto_start_on_boot": false
  },
  "encoding_settings": {
    "enable_utf8_encoding": true,
    "force_utf8_for_paths": true,
    "path_encoding": "utf-8",
    "response_encoding": "utf-8"
  }
}
```

---

**文档版本：** v1.1
**最后更新：** 2026-03-09
**维护者：** 超级ロリ控
