@echo off
chcp 65001 >nul 2>&1

rem 切换到脚本所在目录
cd /d "%~dp0"

echo ===============================================
echo    GPT-SoVITS 加速服务器 - GUI模式
echo ===============================================
echo.

rem 检查Python是否安装
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到Python
    echo 请先安装Python 3.10或更高版本
    pause
    exit /b 1
)

rem 检查依赖是否安装
echo 检查依赖...
pip list | findstr "fastapi" >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在安装依赖...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo 安装依赖失败
        pause
        exit /b 1
    )
)

echo 启动GUI界面...
python start_gui.py

pause
