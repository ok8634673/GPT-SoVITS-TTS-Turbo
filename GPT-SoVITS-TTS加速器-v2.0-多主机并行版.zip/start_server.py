"""
服务器启动脚本
双击运行此文件启动API服务（命令行模式）
"""
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    """启动服务器"""
    try:
        from gpt_sovits_proxy.utils.config import ConfigManager
        from gpt_sovits_proxy.app import create_app
        import uvicorn
        
        # 加载配置
        config_manager = ConfigManager()
        config = config_manager.load()
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           GPT-SoVITS 加速服务器 v{config.version}                    ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  API地址: http://{config.host}:{config.server_port}                             ║
║  服务器数: {len(config.servers)}                                            ║
║                                                              ║
║  按 Ctrl+C 停止服务                                          ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
        """)
        
        # 创建应用
        app = create_app()
        
        # 启动服务
        uvicorn.run(
            app,
            host=config.host,
            port=config.server_port,
            log_level="info"
        )
        
    except ImportError as e:
        print(f"启动失败，缺少依赖: {e}")
        print("请先安装依赖: pip install -r requirements.txt")
        input("按回车键退出...")
    except Exception as e:
        print(f"启动失败: {e}")
        input("按回车键退出...")

if __name__ == "__main__":
    main()
