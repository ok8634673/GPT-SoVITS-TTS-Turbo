"""
音频拼合器
"""
import asyncio
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
import time

from ..utils.audio_utils import AudioUtils
from ..utils.logger import get_logger

logger = get_logger()


@dataclass
class AudioSegment:
    """音频片段"""
    index: int
    text: str
    audio_data: Optional[bytes] = None
    server_id: Optional[str] = None
    status: str = "pending"  # pending, processing, completed, failed
    error: Optional[str] = None
    retry_count: int = 0


class AudioMerger:
    """音频拼合器"""
    
    def __init__(self):
        self.audio_utils = AudioUtils()
        self._progress_callbacks: List[Callable] = []
        
    def add_progress_callback(self, callback: Callable):
        """添加进度回调"""
        self._progress_callbacks.append(callback)
        
    def remove_progress_callback(self, callback: Callable):
        """移除进度回调"""
        if callback in self._progress_callbacks:
            self._progress_callbacks.remove(callback)
            
    def _notify_progress(self, task_id: str, progress: float, message: str = ""):
        """通知进度更新"""
        for callback in self._progress_callbacks:
            try:
                callback(task_id, progress, message)
            except Exception as e:
                logger.error(f"进度回调错误: {e}")
                
    async def merge_segments(
        self, 
        segments: List[AudioSegment],
        task_id: str = ""
    ) -> Optional[bytes]:
        """
        按顺序合并音频片段
        
        Args:
            segments: 音频片段列表
            task_id: 任务ID
            
        Returns:
            合并后的音频数据
        """
        if not segments:
            logger.warning("没有音频片段需要合并")
            return None
            
        # 按索引排序
        sorted_segments = sorted(segments, key=lambda s: s.index)
        
        # 检查是否所有片段都已完成
        completed_segments = [s for s in sorted_segments if s.status == "completed" and s.audio_data]
        
        if len(completed_segments) != len(sorted_segments):
            failed = [s for s in sorted_segments if s.status == "failed"]
            pending = [s for s in sorted_segments if s.status in ("pending", "processing")]
            
            logger.warning(f"音频片段未完成: {len(failed)} 失败, {len(pending)} 未完成")
            
            # 如果有失败的片段，尝试使用已完成的片段
            if not completed_segments:
                return None
                
        # 提取音频数据
        audio_data_list = [s.audio_data for s in sorted(completed_segments, key=lambda s: s.index)]
        
        self._notify_progress(task_id, 90, "正在合并音频片段...")
        
        try:
            # 合并音频
            merged_audio = self.audio_utils.merge_wav_files(audio_data_list)
            
            self._notify_progress(task_id, 100, "音频合并完成")
            
            logger.info(f"成功合并 {len(completed_segments)} 个音频片段，总大小: {len(merged_audio)} bytes")
            
            return merged_audio
            
        except Exception as e:
            logger.error(f"合并音频失败: {e}")
            self._notify_progress(task_id, 0, f"合并失败: {e}")
            return None
            
    async def process_with_retry(
        self,
        segment: AudioSegment,
        process_func: Callable,
        max_retries: int = 3,
        retry_delay: float = 1.0
    ) -> bool:
        """
        带重试的处理
        
        Args:
            segment: 音频片段
            process_func: 处理函数
            max_retries: 最大重试次数
            retry_delay: 重试延迟
            
        Returns:
            是否成功
        """
        segment.status = "processing"
        
        for attempt in range(max_retries + 1):
            try:
                result = await process_func(segment)
                
                if result:
                    segment.status = "completed"
                    return True
                    
            except Exception as e:
                segment.error = str(e)
                segment.retry_count += 1
                
                if attempt < max_retries:
                    logger.warning(f"片段 {segment.index} 处理失败，{retry_delay}秒后重试 ({attempt + 1}/{max_retries}): {e}")
                    await asyncio.sleep(retry_delay)
                else:
                    logger.error(f"片段 {segment.index} 处理失败，已达到最大重试次数: {e}")
                    
        segment.status = "failed"
        return False
        
    def get_segment_info(self, segments: List[AudioSegment]) -> Dict:
        """获取片段信息统计"""
        total = len(segments)
        completed = sum(1 for s in segments if s.status == "completed")
        failed = sum(1 for s in segments if s.status == "failed")
        pending = sum(1 for s in segments if s.status == "pending")
        processing = sum(1 for s in segments if s.status == "processing")
        
        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "pending": pending,
            "processing": processing,
            "progress": (completed / total * 100) if total > 0 else 0
        }
        
    def create_segments(self, texts: List[str]) -> List[AudioSegment]:
        """
        创建音频片段列表
        
        Args:
            texts: 文本列表
            
        Returns:
            音频片段列表
        """
        segments = []
        for i, text in enumerate(texts):
            segment = AudioSegment(
                index=i,
                text=text
            )
            segments.append(segment)
        return segments
