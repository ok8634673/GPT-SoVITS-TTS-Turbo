"""
集群管理器 - 主从模式通讯
"""
import asyncio
import json
import time
from typing import Dict, List, Optional, Callable, Any, Set
from dataclasses import dataclass, field
import aiohttp
from aiohttp import web

from ..models.server_config import ClusterConfig, NodeMode, ServerConfig
from ..utils.logger import get_logger

logger = get_logger()


@dataclass
class NodeInfo:
    """节点信息"""
    node_id: str
    node_name: str
    address: str
    port: int
    status: str = "online"  # online, offline, busy
    last_heartbeat: float = field(default_factory=time.time)
    capabilities: Dict[str, Any] = field(default_factory=dict)


class ClusterManager:
    """集群管理器"""
    
    def __init__(self, config: ClusterConfig):
        self.config = config
        self.mode = config.mode
        self.node_id = config.node_id
        self.node_name = config.node_name
        
        self._slaves: Dict[str, NodeInfo] = {}  # 主节点使用：存储从节点
        self._master: Optional[NodeInfo] = None  # 从节点使用：存储主节点
        self._app: Optional[web.Application] = None
        self._runner: Optional[web.AppRunner] = None
        self._site: Optional[web.TCPSite] = None
        
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._running = False
        
        self._message_handlers: List[Callable] = []
        self._audio_callbacks: List[Callable] = []
        
    def add_message_handler(self, handler: Callable):
        """添加消息处理器"""
        self._message_handlers.append(handler)
        
    def add_audio_callback(self, callback: Callable):
        """添加音频回调"""
        self._audio_callbacks.append(callback)
        
    async def start(self):
        """启动集群服务"""
        if not self.config.enabled:
            logger.info("集群模式未启用")
            return
            
        self._running = True
        
        # 启动HTTP服务
        await self._start_server()
        
        if self.mode == NodeMode.SLAVE:
            # 从节点：注册到主节点
            await self._register_to_master()
        elif self.mode == NodeMode.MASTER:
            # 主节点：启动心跳检测
            self._heartbeat_task = asyncio.create_task(self._heartbeat_check())
            
        logger.info(f"集群服务已启动，模式: {self.mode.value}")
        
    async def stop(self):
        """停止集群服务"""
        self._running = False
        
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
                
        if self._runner:
            await self._runner.cleanup()
            
        logger.info("集群服务已停止")
        
    async def _start_server(self):
        """启动HTTP服务器"""
        self._app = web.Application()
        
        # 注册路由
        self._app.router.add_post('/cluster/register', self._handle_register)
        self._app.router.add_post('/cluster/unregister', self._handle_unregister)
        self._app.router.add_post('/cluster/heartbeat', self._handle_heartbeat)
        self._app.router.add_post('/cluster/tts_request', self._handle_tts_request)
        self._app.router.add_post('/cluster/tts_result', self._handle_tts_result)
        self._app.router.add_get('/cluster/status', self._handle_status)
        
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        
        self._site = web.TCPSite(
            self._runner, 
            self.config.bind_host, 
            self.config.cluster_port
        )
        await self._site.start()
        
        logger.info(f"集群HTTP服务已启动: {self.config.bind_host}:{self.config.cluster_port}")
        
    # ===== HTTP 处理器 =====
    
    async def _handle_register(self, request: web.Request) -> web.Response:
        """处理从节点注册"""
        try:
            data = await request.json()
            
            node = NodeInfo(
                node_id=data.get('node_id'),
                node_name=data.get('node_name'),
                address=data.get('address'),
                port=data.get('port'),
                capabilities=data.get('capabilities', {})
            )
            
            self._slaves[node.node_id] = node
            logger.info(f"从节点注册成功: {node.node_name} ({node.address}:{node.port})")
            
            return web.json_response({
                "success": True,
                "master_id": self.node_id,
                "message": "注册成功"
            })
            
        except Exception as e:
            logger.error(f"处理注册请求失败: {e}")
            return web.json_response({
                "success": False,
                "message": str(e)
            }, status=400)
            
    async def _handle_unregister(self, request: web.Request) -> web.Response:
        """处理从节点注销"""
        try:
            data = await request.json()
            node_id = data.get('node_id')
            
            if node_id in self._slaves:
                node = self._slaves.pop(node_id)
                logger.info(f"从节点注销: {node.node_name}")
                
            return web.json_response({"success": True})
            
        except Exception as e:
            return web.json_response({
                "success": False,
                "message": str(e)
            }, status=400)
            
    async def _handle_heartbeat(self, request: web.Request) -> web.Response:
        """处理心跳"""
        try:
            data = await request.json()
            node_id = data.get('node_id')
            
            if node_id in self._slaves:
                self._slaves[node_id].last_heartbeat = time.time()
                self._slaves[node_id].status = data.get('status', 'online')
                
            return web.json_response({
                "success": True,
                "timestamp": time.time()
            })
            
        except Exception as e:
            return web.json_response({
                "success": False,
                "message": str(e)
            }, status=400)
            
    async def _handle_tts_request(self, request: web.Request) -> web.Response:
        """处理TTS请求（从节点接收）"""
        try:
            data = await request.json()
            
            # 通知处理器
            for handler in self._message_handlers:
                try:
                    asyncio.create_task(handler('tts_request', data))
                except Exception as e:
                    logger.error(f"TTS请求处理器错误: {e}")
                    
            return web.json_response({
                "success": True,
                "message": "请求已接收"
            })
            
        except Exception as e:
            return web.json_response({
                "success": False,
                "message": str(e)
            }, status=400)
            
    async def _handle_tts_result(self, request: web.Request) -> web.Response:
        """处理TTS结果（主节点接收）"""
        try:
            data = await request.json()
            
            # 解码音频数据
            import base64
            audio_data = base64.b64decode(data.get('audio_data', ''))
            
            # 通知回调
            for callback in self._audio_callbacks:
                try:
                    asyncio.create_task(callback(
                        data.get('task_id'),
                        data.get('segment_index'),
                        audio_data
                    ))
                except Exception as e:
                    logger.error(f"TTS结果回调错误: {e}")
                    
            return web.json_response({"success": True})
            
        except Exception as e:
            return web.json_response({
                "success": False,
                "message": str(e)
            }, status=400)
            
    async def _handle_status(self, request: web.Request) -> web.Response:
        """处理状态查询"""
        return web.json_response({
            "node_id": self.node_id,
            "node_name": self.node_name,
            "mode": self.mode.value,
            "status": "online",
            "slaves": len(self._slaves) if self.mode == NodeMode.MASTER else 0
        })
        
    # ===== 从节点方法 =====
    
    async def _register_to_master(self):
        """注册到主节点"""
        if not self.config.master_address:
            logger.error("主节点地址未配置")
            return
            
        try:
            async with aiohttp.ClientSession() as session:
                data = {
                    "node_id": self.node_id,
                    "node_name": self.node_name,
                    "address": self.config.bind_host,
                    "port": self.config.cluster_port,
                    "capabilities": {
                        "max_concurrent": 5,
                        "supported_formats": ["wav"]
                    }
                }
                
                async with session.post(
                    f"http://{self.config.master_address}:{self.config.master_port or 9999}/cluster/register",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    
                    if response.status == 200:
                        result = await response.json()
                        if result.get('success'):
                            self._master = NodeInfo(
                                node_id=result.get('master_id'),
                                node_name="Master",
                                address=self.config.master_address,
                                port=self.config.master_port or 9999
                            )
                            logger.info("成功注册到主节点")
                            
                            # 启动心跳
                            self._heartbeat_task = asyncio.create_task(self._send_heartbeat())
                        else:
                            logger.error(f"注册失败: {result.get('message')}")
                    else:
                        logger.error(f"注册失败: HTTP {response.status}")
                        
        except Exception as e:
            logger.error(f"注册到主节点失败: {e}")
            
    async def _send_heartbeat(self):
        """发送心跳"""
        while self._running and self._master:
            try:
                await asyncio.sleep(30)  # 每30秒发送一次
                
                async with aiohttp.ClientSession() as session:
                    data = {
                        "node_id": self.node_id,
                        "status": "online"
                    }
                    
                    async with session.post(
                        f"http://{self._master.address}:{self._master.port}/cluster/heartbeat",
                        json=data,
                        timeout=aiohttp.ClientTimeout(total=5)
                    ) as response:
                        
                        if response.status != 200:
                            logger.warning("心跳发送失败")
                            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"心跳发送异常: {e}")
                
    # ===== 主节点方法 =====
    
    async def _heartbeat_check(self):
        """心跳检测（主节点）"""
        while self._running:
            try:
                await asyncio.sleep(60)  # 每分钟检查一次
                
                current_time = time.time()
                offline_nodes = []
                
                for node_id, node in self._slaves.items():
                    if current_time - node.last_heartbeat > 120:  # 2分钟无心跳视为离线
                        node.status = "offline"
                        offline_nodes.append(node_id)
                        logger.warning(f"从节点离线: {node.node_name}")
                        
                # 清理离线节点
                for node_id in offline_nodes:
                    del self._slaves[node_id]
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"心跳检测异常: {e}")
                
    async def send_tts_request_to_slave(
        self, 
        slave_id: str, 
        task_id: str,
        segment_index: int,
        request_data: Dict
    ) -> bool:
        """
        发送TTS请求到从节点
        
        Args:
            slave_id: 从节点ID
            task_id: 任务ID
            segment_index: 片段索引
            request_data: 请求数据
            
        Returns:
            是否成功
        """
        slave = self._slaves.get(slave_id)
        if not slave:
            logger.error(f"从节点不存在: {slave_id}")
            return False
            
        try:
            async with aiohttp.ClientSession() as session:
                data = {
                    "task_id": task_id,
                    "segment_index": segment_index,
                    "request": request_data
                }
                
                async with session.post(
                    f"http://{slave.address}:{slave.port}/cluster/tts_request",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    
                    if response.status == 200:
                        result = await response.json()
                        return result.get('success', False)
                    else:
                        return False
                        
        except Exception as e:
            logger.error(f"发送TTS请求到从节点失败: {e}")
            return False
            
    async def send_tts_result_to_master(
        self,
        task_id: str,
        segment_index: int,
        audio_data: bytes
    ) -> bool:
        """
        发送TTS结果到主节点
        
        Args:
            task_id: 任务ID
            segment_index: 片段索引
            audio_data: 音频数据
            
        Returns:
            是否成功
        """
        if not self._master:
            logger.error("未连接到主节点")
            return False
            
        try:
            import base64
            
            async with aiohttp.ClientSession() as session:
                data = {
                    "task_id": task_id,
                    "segment_index": segment_index,
                    "audio_data": base64.b64encode(audio_data).decode('utf-8')
                }
                
                async with session.post(
                    f"http://{self._master.address}:{self._master.port}/cluster/tts_result",
                    json=data,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    
                    if response.status == 200:
                        result = await response.json()
                        return result.get('success', False)
                    else:
                        return False
                        
        except Exception as e:
            logger.error(f"发送TTS结果到主节点失败: {e}")
            return False
            
    def get_slave_nodes(self) -> List[NodeInfo]:
        """获取所有从节点"""
        return list(self._slaves.values())
        
    def get_online_slaves(self) -> List[NodeInfo]:
        """获取在线从节点"""
        return [n for n in self._slaves.values() if n.status == "online"]
        
    def is_master(self) -> bool:
        """是否为主节点"""
        return self.mode == NodeMode.MASTER and self.config.enabled
        
    def is_slave(self) -> bool:
        """是否为从节点"""
        return self.mode == NodeMode.SLAVE and self.config.enabled
