"""
任务队列管理
"""
import asyncio
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime
import time
import uuid

from ..models.server_config import TTSTask, TaskStatus, TTSRequest
from ..utils.logger import get_logger

logger = get_logger()


@dataclass
class TaskInfo:
    """任务信息"""
    task: TTSTask
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    callbacks: List[Callable] = field(default_factory=list)


class TaskQueue:
    """任务队列管理器"""
    
    def __init__(self, max_concurrent: int = 10):
        self.max_concurrent = max_concurrent
        self._tasks: Dict[str, TaskInfo] = {}
        self._queue: asyncio.Queue = asyncio.Queue()
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._running = False
        self._worker_task: Optional[asyncio.Task] = None
        self._progress_callbacks: List[Callable] = []
        
    def add_progress_callback(self, callback: Callable):
        """添加进度回调"""
        self._progress_callbacks.append(callback)
        
    def remove_progress_callback(self, callback: Callable):
        """移除进度回调"""
        if callback in self._progress_callbacks:
            self._progress_callbacks.remove(callback)
            
    def _notify_progress(self, task_id: str, progress: float, message: str = ""):
        """通知进度更新"""
        for callback in self._progress_callbacks:
            try:
                callback(task_id, progress, message)
            except Exception as e:
                logger.error(f"进度回调错误: {e}")
                
    async def start(self):
        """启动任务队列"""
        if self._running:
            return
            
        self._running = True
        self._worker_task = asyncio.create_task(self._worker())
        logger.info("任务队列已启动")
        
    async def stop(self):
        """停止任务队列"""
        self._running = False
        
        if self._worker_task:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
                
        logger.info("任务队列已停止")
        
    async def _worker(self):
        """工作协程"""
        while self._running:
            try:
                task_id = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                task_info = self._tasks.get(task_id)
                
                if task_info and task_info.task.status == TaskStatus.PENDING:
                    asyncio.create_task(self._process_task(task_id))
                    
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"工作协程错误: {e}")
                
    async def _process_task(self, task_id: str):
        """处理单个任务"""
        async with self._semaphore:
            task_info = self._tasks.get(task_id)
            if not task_info:
                return
                
            task = task_info.task
            task.status = TaskStatus.PROCESSING
            
            self._notify_progress(task_id, 10, "任务开始处理")
            
            try:
                # 执行回调
                for callback in task_info.callbacks:
                    try:
                        result = await callback(task)
                        if result:
                            task.result_audio = result
                    except Exception as e:
                        logger.error(f"任务回调错误: {e}")
                        
                if task.result_audio:
                    task.status = TaskStatus.COMPLETED
                    task.progress = 100.0
                    task.completed_at = time.time()
                    self._notify_progress(task_id, 100, "任务完成")
                    logger.info(f"任务 {task_id} 完成")
                else:
                    task.status = TaskStatus.FAILED
                    task.error_message = "处理结果为空"
                    self._notify_progress(task_id, 0, "任务失败: 结果为空")
                    logger.warning(f"任务 {task_id} 失败: 结果为空")
                    
            except Exception as e:
                task.status = TaskStatus.FAILED
                task.error_message = str(e)
                self._notify_progress(task_id, 0, f"任务失败: {e}")
                logger.error(f"任务 {task_id} 处理失败: {e}")
                
    async def submit_task(
        self, 
        request: TTSRequest,
        process_callback: Optional[Callable] = None
    ) -> str:
        """
        提交任务
        
        Args:
            request: TTS请求
            process_callback: 处理回调
            
        Returns:
            任务ID
        """
        task = TTSTask(request=request)
        task_id = task.id
        
        task_info = TaskInfo(task=task)
        if process_callback:
            task_info.callbacks.append(process_callback)
            
        self._tasks[task_id] = task_info
        await self._queue.put(task_id)
        
        logger.info(f"任务 {task_id} 已提交")
        return task_id
        
    def get_task(self, task_id: str) -> Optional[TTSTask]:
        """获取任务"""
        task_info = self._tasks.get(task_id)
        return task_info.task if task_info else None
        
    def get_all_tasks(self, status: Optional[TaskStatus] = None) -> List[TTSTask]:
        """获取所有任务"""
        tasks = []
        for task_info in self._tasks.values():
            if status is None or task_info.task.status == status:
                tasks.append(task_info.task)
        return tasks
        
    def get_recent_tasks(self, count: int = 10) -> List[TTSTask]:
        """获取最近任务"""
        sorted_tasks = sorted(
            self._tasks.values(),
            key=lambda t: t.created_at,
            reverse=True
        )
        return [t.task for t in sorted_tasks[:count]]
        
    def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        task_info = self._tasks.get(task_id)
        if task_info and task_info.task.status in (TaskStatus.PENDING, TaskStatus.PROCESSING):
            task_info.task.status = TaskStatus.CANCELLED
            logger.info(f"任务 {task_id} 已取消")
            return True
        return False
        
    def remove_task(self, task_id: str) -> bool:
        """移除任务"""
        if task_id in self._tasks:
            del self._tasks[task_id]
            return True
        return False
        
    def clear_completed(self):
        """清理已完成任务"""
        to_remove = [
            task_id for task_id, task_info in self._tasks.items()
            if task_info.task.status in (TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED)
        ]
        for task_id in to_remove:
            del self._tasks[task_id]
        logger.info(f"清理了 {len(to_remove)} 个已完成任务")
        
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = len(self._tasks)
        pending = sum(1 for t in self._tasks.values() if t.task.status == TaskStatus.PENDING)
        processing = sum(1 for t in self._tasks.values() if t.task.status == TaskStatus.PROCESSING)
        completed = sum(1 for t in self._tasks.values() if t.task.status == TaskStatus.COMPLETED)
        failed = sum(1 for t in self._tasks.values() if t.task.status == TaskStatus.FAILED)
        
        return {
            "total": total,
            "pending": pending,
            "processing": processing,
            "completed": completed,
            "failed": failed,
            "queue_size": self._queue.qsize()
        }
