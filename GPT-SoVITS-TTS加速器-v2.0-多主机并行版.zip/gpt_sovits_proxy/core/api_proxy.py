"""
API代理核心
"""
import asyncio
import aiohttp
import time
from typing import List, Optional, Dict, Any
import json

from ..models.server_config import (
    ServerConfig, TTSRequest, TTSTask, ServerStatus,
    TaskStatus
)
from ..utils.audio_utils import AudioUtils
from ..utils.logger import get_logger
from .load_balancer import LoadBalancer
from .audio_merger import AudioMerger, AudioSegment
from .task_queue import TaskQueue

logger = get_logger()


class APIProxy:
    """API代理"""
    
    def __init__(
        self,
        load_balancer: LoadBalancer,
        task_queue: TaskQueue,
        audio_merger: AudioMerger,
        request_timeout: int = 300,
        max_retries: int = 3,
        retry_delay: float = 1.0
    ):
        self.load_balancer = load_balancer
        self.task_queue = task_queue
        self.audio_merger = audio_merger
        self.request_timeout = request_timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.audio_utils = AudioUtils()
        
    async def process_tts_request(self, request: TTSRequest) -> Optional[bytes]:
        """
        处理TTS请求
        
        Args:
            request: TTS请求
            
        Returns:
            音频数据
        """
        # 分割文本
        segments_text = self.audio_utils.split_text(
            request.text,
            method=request.text_split_method
        )
        
        logger.info(f"文本已分割为 {len(segments_text)} 个片段")
        
        # 创建音频片段
        segments = self.audio_merger.create_segments(segments_text)
        
        # 为每个片段选择服务器
        if request.server_id:
            # 使用指定的服务器
            server = self.load_balancer.get_server(request.server_id)
            if server and server.is_available():
                logger.info(f"使用指定服务器: {server.name} ({server.address}:{server.port})")
                for segment in segments:
                    segment.server_id = server.id
            else:
                logger.warning(f"指定的服务器不可用: {request.server_id}")
                # 回退到负载均衡
                servers = await self.load_balancer.select_servers_for_segments(len(segments))
                for i, (segment, srv) in enumerate(zip(segments, servers)):
                    if srv:
                        segment.server_id = srv.id
                    else:
                        logger.error(f"片段 {i} 没有可用的服务器")
        else:
            # 使用负载均衡选择服务器
            servers = await self.load_balancer.select_servers_for_segments(len(segments))
            for i, (segment, server) in enumerate(zip(segments, servers)):
                if server:
                    segment.server_id = server.id
                else:
                    logger.error(f"片段 {i} 没有可用的服务器")
                
        # 并发处理所有片段
        tasks = []
        for segment in segments:
            if segment.server_id:
                task = self._process_segment(segment, request)
                tasks.append(task)
            else:
                segment.status = "failed"
                segment.error = "没有可用的服务器"
                
        # 等待所有任务完成
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
            
        # 合并音频
        merged_audio = await self.audio_merger.merge_segments(segments)
        
        return merged_audio
        
    async def _process_segment(self, segment: AudioSegment, request: TTSRequest):
        """处理单个片段"""
        server = self.load_balancer.get_server(segment.server_id)
        if not server:
            segment.status = "failed"
            segment.error = "服务器不存在"
            return
            
        # 构建请求参数
        payload = self._build_payload(request, segment.text, server)
        
        # 增加连接数
        self.load_balancer.increment_connection(server.id)
        
        start_time = time.time()
        
        try:
            async with aiohttp.ClientSession() as session:
                # 手动序列化JSON以确保UTF-8编码
                import json
                json_payload = json.dumps(payload, ensure_ascii=False).encode('utf-8')
                
                # 记录发送的请求参数（仅用于调试）
                logger.debug(f"发送请求到 {server.get_url()}")
                logger.debug(f"请求参数: {json.dumps(payload, ensure_ascii=False)}")
                
                async with session.post(
                    server.get_url(),
                    data=json_payload,
                    timeout=aiohttp.ClientTimeout(total=self.request_timeout),
                    headers={"Content-Type": "application/json; charset=utf-8"}
                ) as response:
                    
                    if response.status == 200:
                        audio_data = await response.read()
                        segment.audio_data = audio_data
                        segment.status = "completed"
                        
                        # 记录成功
                        response_time = time.time() - start_time
                        self.load_balancer.record_success(server.id, response_time)
                        
                        logger.debug(f"片段 {segment.index} 处理成功，大小: {len(audio_data)} bytes")
                    else:
                        error_text = await response.text()
                        segment.status = "failed"
                        segment.error = f"HTTP {response.status}: {error_text}"
                        self.load_balancer.record_failure(server.id)
                        logger.error(f"片段 {segment.index} 处理失败: {segment.error}")
                        
                        # 尝试其他服务器
                        await self._retry_with_other_servers(segment, request, server.id)
                        
                        # 400 Bad Request通常是请求参数问题，不将服务器状态设置为ERROR
                        
        except asyncio.TimeoutError:
            segment.status = "failed"
            segment.error = "请求超时"
            self.load_balancer.record_failure(server.id)
            logger.error(f"片段 {segment.index} 请求超时")
            
            # 尝试其他服务器
            await self._retry_with_other_servers(segment, request, server.id)
            
        except Exception as e:
            segment.status = "failed"
            segment.error = str(e)
            self.load_balancer.record_failure(server.id)
            logger.error(f"片段 {segment.index} 处理异常: {e}")
            
            # 尝试其他服务器
            await self._retry_with_other_servers(segment, request, server.id)
            
        finally:
            # 减少连接数
            self.load_balancer.decrement_connection(server.id)
    
    async def _retry_with_other_servers(self, segment: AudioSegment, request: TTSRequest, original_server_id: str):
        """尝试使用其他服务器处理片段"""
        # 获取所有可用服务器，排除原始服务器
        available_servers = [s for s in self.load_balancer.get_available_servers() if s.id != original_server_id]
        
        if not available_servers:
            logger.warning(f"没有其他可用服务器，片段 {segment.index} 处理失败")
            return
        
        # 尝试所有可用的服务器
        for retry_server in available_servers:
            logger.info(f"尝试使用备用服务器 {retry_server.name} 处理片段 {segment.index}")
            
            # 构建请求参数
            payload = self._build_payload(request, segment.text, retry_server)
            
            # 增加连接数
            self.load_balancer.increment_connection(retry_server.id)
            
            start_time = time.time()
            
            try:
                async with aiohttp.ClientSession() as session:
                    # 手动序列化JSON以确保UTF-8编码
                    import json
                    json_payload = json.dumps(payload, ensure_ascii=False).encode('utf-8')
                    
                    async with session.post(
                        retry_server.get_url(),
                        data=json_payload,
                        timeout=aiohttp.ClientTimeout(total=self.request_timeout),
                        headers={"Content-Type": "application/json; charset=utf-8"}
                    ) as response:
                        
                        if response.status == 200:
                            audio_data = await response.read()
                            segment.audio_data = audio_data
                            segment.status = "completed"
                            segment.server_id = retry_server.id  # 更新服务器ID
                            
                            # 记录成功
                            response_time = time.time() - start_time
                            self.load_balancer.record_success(retry_server.id, response_time)
                            
                            logger.debug(f"片段 {segment.index} 使用备用服务器处理成功，大小: {len(audio_data)} bytes")
                            return  # 成功后返回
                        else:
                            error_text = await response.text()
                            segment.status = "failed"
                            segment.error = f"备用服务器失败: HTTP {response.status}: {error_text}"
                            self.load_balancer.record_failure(retry_server.id)
                            logger.error(f"片段 {segment.index} 备用服务器处理失败: {segment.error}")
                            
                            # 400 Bad Request通常是请求参数问题，不将服务器状态设置为ERROR
                            
            except asyncio.TimeoutError:
                segment.status = "failed"
                segment.error = "备用服务器请求超时"
                self.load_balancer.record_failure(retry_server.id)
                logger.error(f"片段 {segment.index} 备用服务器请求超时")
                
            except Exception as e:
                segment.status = "failed"
                segment.error = f"备用服务器异常: {str(e)}"
                self.load_balancer.record_failure(retry_server.id)
                logger.error(f"片段 {segment.index} 备用服务器处理异常: {e}")
                
            finally:
                # 减少连接数
                self.load_balancer.decrement_connection(retry_server.id)
            
    def _build_payload(
        self, 
        request: TTSRequest, 
        text: str,
        server: ServerConfig
    ) -> Dict[str, Any]:
        """构建请求参数"""
        payload = {
            "text": text,
            "text_lang": request.text_lang,
            "top_k": request.top_k,
            "top_p": request.top_p,
            "temperature": request.temperature,
            "text_split_method": request.text_split_method,
            "batch_size": request.batch_size,
            "speed_factor": request.speed_factor
        }
        
        # 使用请求中的参考音频配置，如果没有则使用服务器的
        if request.ref_audio_path:
            payload["ref_audio_path"] = request.ref_audio_path
        else:
            # 使用服务器的参考音频路径
            payload["ref_audio_path"] = server.ref_audio_path
            
        if request.prompt_text:
            payload["prompt_text"] = request.prompt_text
        else:
            payload["prompt_text"] = server.prompt_text
            
        if request.prompt_lang:
            payload["prompt_lang"] = request.prompt_lang
        else:
            payload["prompt_lang"] = server.prompt_lang
            
        if request.output_dir:
            payload["output_dir"] = request.output_dir
            
        return payload
        
    async def submit_tts_task(self, request: TTSRequest) -> str:
        """
        提交TTS任务到队列
        
        Args:
            request: TTS请求
            
        Returns:
            任务ID
        """
        task_id = await self.task_queue.submit_task(
            request,
            process_callback=self._process_task_callback
        )
        return task_id
        
    async def _process_task_callback(self, task: TTSTask) -> Optional[bytes]:
        """任务处理回调"""
        result = await self.process_tts_request(task.request)
        return result
        
    async def test_server(self, server: ServerConfig) -> Dict[str, Any]:
        """
        测试服务器连接
        
        Args:
            server: 服务器配置
            
        Returns:
            测试结果
        """
        result = {
            "success": False,
            "message": "",
            "response_time": 0.0
        }
        
        start_time = time.time()
        
        try:
            async with aiohttp.ClientSession() as session:
                # 尝试连接服务器
                async with session.get(
                    f"http://{server.address}:{server.port}",
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as response:
                    result["response_time"] = time.time() - start_time
                    
                    if response.status in (200, 404):  # 404也是正常的，说明服务在运行
                        result["success"] = True
                        result["message"] = f"连接成功 ({result['response_time']:.2f}s)"
                        server.status = ServerStatus.ONLINE
                    else:
                        result["message"] = f"HTTP {response.status}"
                        server.status = ServerStatus.ERROR
                        
        except asyncio.TimeoutError:
            result["response_time"] = time.time() - start_time
            result["message"] = "连接超时"
            server.status = ServerStatus.OFFLINE
            
        except Exception as e:
            result["response_time"] = time.time() - start_time
            result["message"] = f"连接失败: {str(e)}"
            server.status = ServerStatus.OFFLINE
            
        return result
        
    async def health_check_all(self) -> Dict[str, Dict[str, Any]]:
        """健康检查所有服务器"""
        results = {}
        
        for server in self.load_balancer.servers:
            if server.enabled:
                results[server.id] = await self.test_server(server)
                
        return results
