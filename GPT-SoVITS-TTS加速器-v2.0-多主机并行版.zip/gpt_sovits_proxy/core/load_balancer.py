"""
负载均衡器
"""
import asyncio
import random
from typing import List, Optional, Dict
from dataclasses import dataclass, field
import time

from ..models.server_config import ServerConfig, ServerStatus, LoadBalanceStrategy
from ..utils.logger import get_logger

logger = get_logger()


@dataclass
class ServerStats:
    """服务器统计信息"""
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    avg_response_time: float = 0.0
    last_check_time: float = field(default_factory=time.time)


class LoadBalancer:
    """负载均衡器"""
    
    def __init__(self, strategy: LoadBalanceStrategy = LoadBalanceStrategy.ROUND_ROBIN):
        self.strategy = strategy
        self.servers: List[ServerConfig] = []
        self._round_robin_index = 0
        self._server_stats: Dict[str, ServerStats] = {}
        self._lock = asyncio.Lock()
        
    def add_server(self, server: ServerConfig):
        """添加服务器"""
        self.servers.append(server)
        self._server_stats[server.id] = ServerStats()
        logger.info(f"添加服务器: {server.name} ({server.address}:{server.port})")
        
    def remove_server(self, server_id: str):
        """移除服务器"""
        self.servers = [s for s in self.servers if s.id != server_id]
        if server_id in self._server_stats:
            del self._server_stats[server_id]
        logger.info(f"移除服务器: {server_id}")
        
    def update_server(self, server: ServerConfig):
        """更新服务器配置"""
        for i, s in enumerate(self.servers):
            if s.id == server.id:
                # 保留运行时状态
                server.status = s.status
                server.current_connections = s.current_connections
                server.total_requests = s.total_requests
                server.failed_requests = s.failed_requests
                self.servers[i] = server
                logger.info(f"更新服务器: {server.name}")
                break
                
    def get_server(self, server_id: str) -> Optional[ServerConfig]:
        """获取指定服务器"""
        for server in self.servers:
            if server.id == server_id:
                return server
        return None
        
    async def select_server(self) -> Optional[ServerConfig]:
        """选择服务器"""
        async with self._lock:
            available_servers = [s for s in self.servers if s.is_available()]
            
            if not available_servers:
                logger.warning("没有可用的服务器")
                return None
                
            if self.strategy == LoadBalanceStrategy.ROUND_ROBIN:
                return await self._round_robin_select(available_servers)
            elif self.strategy == LoadBalanceStrategy.LEAST_CONNECTIONS:
                return await self._least_connections_select(available_servers)
            elif self.strategy == LoadBalanceStrategy.WEIGHTED_ROUND_ROBIN:
                return await self._weighted_round_robin_select(available_servers)
            else:
                return await self._round_robin_select(available_servers)
                
    async def _round_robin_select(self, servers: List[ServerConfig]) -> ServerConfig:
        """轮询选择"""
        server = servers[self._round_robin_index % len(servers)]
        self._round_robin_index = (self._round_robin_index + 1) % len(servers)
        return server
        
    async def _least_connections_select(self, servers: List[ServerConfig]) -> ServerConfig:
        """最少连接选择"""
        return min(servers, key=lambda s: s.current_connections)
        
    async def _weighted_round_robin_select(self, servers: List[ServerConfig]) -> ServerConfig:
        """加权轮询选择"""
        total_weight = sum(s.weight for s in servers)
        if total_weight == 0:
            return await self._round_robin_select(servers)
            
        # 基于权重选择
        point = random.randint(0, total_weight - 1)
        current_weight = 0
        
        for server in servers:
            current_weight += server.weight
            if point < current_weight:
                return server
                
        return servers[-1]
        
    async def select_servers_for_segments(self, segments_count: int) -> List[Optional[ServerConfig]]:
        """
        为多个文本段选择服务器
        
        Args:
            segments_count: 文本段数量
            
        Returns:
            服务器列表（与文本段一一对应）
        """
        servers = []
        for _ in range(segments_count):
            server = await self.select_server()
            servers.append(server)
        return servers
        
    def update_server_status(self, server_id: str, status: ServerStatus):
        """更新服务器状态"""
        server = self.get_server(server_id)
        if server:
            old_status = server.status
            server.status = status
            if old_status != status:
                logger.info(f"服务器 {server.name} 状态变更: {old_status.value} -> {status.value}")
                
    def increment_connection(self, server_id: str):
        """增加连接数"""
        server = self.get_server(server_id)
        if server:
            server.current_connections += 1
            server.total_requests += 1
            
    def decrement_connection(self, server_id: str):
        """减少连接数"""
        server = self.get_server(server_id)
        if server:
            server.current_connections = max(0, server.current_connections - 1)
            
    def record_success(self, server_id: str, response_time: float):
        """记录成功请求"""
        if server_id in self._server_stats:
            stats = self._server_stats[server_id]
            stats.successful_requests += 1
            stats.total_requests += 1
            # 更新平均响应时间
            stats.avg_response_time = (
                (stats.avg_response_time * (stats.total_requests - 1) + response_time) 
                / stats.total_requests
            )
            
    def record_failure(self, server_id: str):
        """记录失败请求"""
        server = self.get_server(server_id)
        if server:
            server.failed_requests += 1
            
        if server_id in self._server_stats:
            self._server_stats[server_id].failed_requests += 1
            self._server_stats[server_id].total_requests += 1
            
    def get_server_stats(self, server_id: str) -> Optional[ServerStats]:
        """获取服务器统计"""
        return self._server_stats.get(server_id)
        
    def get_all_stats(self) -> Dict[str, ServerStats]:
        """获取所有统计"""
        return self._server_stats.copy()
        
    def get_available_servers(self) -> List[ServerConfig]:
        """获取可用服务器列表"""
        return [s for s in self.servers if s.is_available()]
        
    async def health_check(self) -> Dict[str, bool]:
        """健康检查"""
        results = {}
        
        for server in self.servers:
            if not server.enabled:
                continue
                
            try:
                import aiohttp
                # 先尝试简单的GET请求检查服务器是否在线
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"http://{server.address}:{server.port}",
                        timeout=aiohttp.ClientTimeout(total=5)
                    ) as response:
                        # 只要能连接上就认为服务在线
                        self.update_server_status(server.id, ServerStatus.ONLINE)
                        results[server.id] = True
            except Exception as e:
                logger.debug(f"健康检查失败 {server.name}: {e}")
                self.update_server_status(server.id, ServerStatus.OFFLINE)
                results[server.id] = False
                
        return results
