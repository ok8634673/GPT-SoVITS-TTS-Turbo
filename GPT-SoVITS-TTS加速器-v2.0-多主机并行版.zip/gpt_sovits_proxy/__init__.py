"""
GPT-SoVITS 加速服务器

一个基于Python的带GUI的API请求转发和负载均衡服务，
用于加速GPT-SoVITS语音生成。
"""

__version__ = "1.0.0"
__author__ = "GPT-SoVITS-Proxy"
