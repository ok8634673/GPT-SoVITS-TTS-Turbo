"""
主入口文件
"""
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="GPT-SoVITS 加速服务器")
    parser.add_argument("--gui", action="store_true", help="启动GUI界面")
    parser.add_argument("--host", default="0.0.0.0", help="绑定主机")
    parser.add_argument("--port", type=int, default=9889, help="服务端口")
    parser.add_argument("--config", help="配置文件路径")
    
    args = parser.parse_args()
    
    if args.gui:
        # 启动GUI
        from gpt_sovits_proxy.gui.main_window import MainWindow
        import customtkinter as ctk
        
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        
        app = MainWindow()
        app.run()
    else:
        # 启动命令行服务
        from gpt_sovits_proxy.utils.config import ConfigManager
        from gpt_sovits_proxy.app import create_app
        import uvicorn
        
        # 加载配置
        config_manager = ConfigManager(args.config)
        config = config_manager.load()
        
        # 覆盖命令行参数
        host = args.host or config.host
        port = args.port or config.server_port
        
        print(f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║           GPT-SoVITS 加速服务器 v{config.version}                    ║
║                                                              ║
╠══════════════════════════════════════════════════════════════╣
║  API地址: http://{host}:{port}                             ║
║  服务器数: {len(config.servers)}                                            ║
║                                                              ║
║  使用 --gui 参数启动图形界面                                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
        """)
        
        app = create_app()
        uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()
