"""
服务器配置数据模型
"""
from typing import Optional, List, Literal
from pydantic import BaseModel, Field
from enum import Enum
import uuid


class LoadBalanceStrategy(str, Enum):
    """负载均衡策略"""
    ROUND_ROBIN = "round-robin"
    LEAST_CONNECTIONS = "least-connections"
    WEIGHTED_ROUND_ROBIN = "weighted-round-robin"


class ServerStatus(str, Enum):
    """服务器状态"""
    ONLINE = "online"
    OFFLINE = "offline"
    BUSY = "busy"
    ERROR = "error"


class NodeMode(str, Enum):
    """节点模式"""
    MASTER = "master"
    SLAVE = "slave"
    STANDALONE = "standalone"


class ServerConfig(BaseModel):
    """GPT-SoVITS服务器配置"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = Field(..., description="服务器名称")
    address: str = Field(..., description="服务器地址")
    port: int = Field(default=9880, description="API端口")
    ref_audio_path: str = Field(..., description="参考音频路径")
    prompt_text: str = Field(..., description="参考音频文本")
    prompt_lang: str = Field(default="zh", description="参考音频语言")
    enabled: bool = Field(default=True, description="是否启用")
    weight: int = Field(default=1, description="权重（用于加权轮询）")
    max_connections: int = Field(default=10, description="最大连接数")
    
    # 运行时状态（不保存到配置）
    status: ServerStatus = Field(default=ServerStatus.OFFLINE, exclude=True)
    current_connections: int = Field(default=0, exclude=True)
    total_requests: int = Field(default=0, exclude=True)
    failed_requests: int = Field(default=0, exclude=True)
    
    class Config:
        json_schema_extra = {
            "example": {
                "id": "srv001",
                "name": "服务器1",
                "address": "192.168.1.1",
                "port": 9880,
                "ref_audio_path": "F:/GPT-SoVITS/audio/ref.wav",
                "prompt_text": "参考音频文本",
                "prompt_lang": "zh",
                "enabled": True,
                "weight": 1,
                "max_connections": 10
            }
        }
    
    def get_url(self) -> str:
        """获取服务器URL"""
        return f"http://{self.address}:{self.port}/tts"
    
    def is_available(self) -> bool:
        """检查服务器是否可用"""
        return (self.enabled and 
                self.status == ServerStatus.ONLINE and 
                self.current_connections < self.max_connections)


class DefaultTTSConfig(BaseModel):
    """默认TTS配置"""
    text_lang: str = Field(default="auto", description="文本语言")
    top_k: int = Field(default=5, description="Top-K采样")
    top_p: float = Field(default=1.0, description="Top-P采样")
    temperature: float = Field(default=1.0, description="温度参数")
    text_split_method: str = Field(default="cut4", description="文本分割方法")
    batch_size: int = Field(default=1, description="批处理大小")
    speed_factor: float = Field(default=1.0, description="语速因子")


class UISettings(BaseModel):
    """UI设置"""
    theme: Literal["dark", "light"] = Field(default="dark", description="主题")
    window_width: int = Field(default=1200, description="窗口宽度")
    window_height: int = Field(default=800, description="窗口高度")
    auto_save: bool = Field(default=True, description="自动保存")
    auto_save_interval: int = Field(default=60, description="自动保存间隔(秒)")
    cache_folder: str = Field(default="cache", description="缓存文件夹路径")
    auto_start_service: bool = Field(default=False, description="自动启动服务")
    auto_start_on_boot: bool = Field(default=False, description="开机自启")


class ClusterConfig(BaseModel):
    """集群配置"""
    enabled: bool = Field(default=False, description="启用集群模式")
    mode: NodeMode = Field(default=NodeMode.STANDALONE, description="节点模式")
    node_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8], description="节点ID")
    node_name: str = Field(default="节点1", description="节点名称")
    bind_host: str = Field(default="0.0.0.0", description="绑定主机")
    cluster_port: int = Field(default=9999, description="集群通讯端口")
    master_address: Optional[str] = Field(default=None, description="主节点地址")
    master_port: Optional[int] = Field(default=None, description="主节点端口")
    slave_addresses: List[str] = Field(default_factory=list, description="从节点地址列表")


class ProxyConfig(BaseModel):
    """代理服务器主配置"""
    version: str = Field(default="1.0.0", description="版本")
    server_name: str = Field(default="GPT-SoVITS-Proxy", description="服务器名称")
    server_port: int = Field(default=9889, description="服务端口")
    host: str = Field(default="0.0.0.0", description="绑定主机")
    
    servers: List[ServerConfig] = Field(default_factory=list, description="服务器列表")
    default_config: DefaultTTSConfig = Field(default_factory=DefaultTTSConfig, description="默认TTS配置")
    ui_settings: UISettings = Field(default_factory=UISettings, description="UI设置")
    cluster: ClusterConfig = Field(default_factory=ClusterConfig, description="集群配置")
    
    # 负载均衡策略
    load_balance_strategy: LoadBalanceStrategy = Field(
        default=LoadBalanceStrategy.ROUND_ROBIN, 
        description="负载均衡策略"
    )
    
    # 高级设置
    request_timeout: int = Field(default=300, description="请求超时(秒)")
    max_retries: int = Field(default=3, description="最大重试次数")
    retry_delay: float = Field(default=1.0, description="重试延迟(秒)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "version": "1.0.0",
                "server_name": "GPT-SoVITS-Proxy",
                "server_port": 9889,
                "host": "0.0.0.0",
                "servers": [],
                "load_balance_strategy": "round-robin"
            }
        }


class TTSRequest(BaseModel):
    """TTS请求模型"""
    ref_audio_path: Optional[str] = Field(default=None, description="参考音频路径")
    prompt_text: Optional[str] = Field(default=None, description="参考音频文本")
    prompt_lang: Optional[str] = Field(default=None, description="参考音频语言")
    text: str = Field(..., description="要合成的文本")
    text_lang: str = Field(default="auto", description="文本语言")
    output_dir: Optional[str] = Field(default=None, description="输出目录")
    top_k: int = Field(default=5, description="Top-K采样")
    top_p: float = Field(default=1.0, description="Top-P采样")
    temperature: float = Field(default=1.0, description="温度参数")
    text_split_method: str = Field(default="cut4", description="文本分割方法")
    batch_size: int = Field(default=1, description="批处理大小")
    speed_factor: float = Field(default=1.0, description="语速因子")
    server_id: Optional[str] = Field(default=None, description="指定服务器ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "text": "你好，我是可莉！",
                "text_lang": "auto",
                "top_k": 5,
                "top_p": 1.0,
                "temperature": 1.0,
                "text_split_method": "cut4",
                "batch_size": 1,
                "speed_factor": 1.0
            }
        }


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TTSTask(BaseModel):
    """TTS任务模型"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    status: TaskStatus = Field(default=TaskStatus.PENDING)
    request: TTSRequest
    created_at: float = Field(default_factory=lambda: __import__('time').time())
    completed_at: Optional[float] = Field(default=None)
    progress: float = Field(default=0.0, description="进度 0-100")
    result_audio: Optional[bytes] = Field(default=None, exclude=True)
    error_message: Optional[str] = Field(default=None)
    segments: List[dict] = Field(default_factory=list, description="文本分段信息")
    server_assignments: dict = Field(default_factory=dict, description="服务器分配")
