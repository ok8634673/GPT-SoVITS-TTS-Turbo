"""
数据模型模块
"""
from .server_config import ServerConfig, ProxyConfig, TTSRequest

__all__ = ['ServerConfig', 'ProxyConfig', 'TTSRequest']
