"""
配置管理工具
"""
import json
import os
from pathlib import Path
from typing import Optional, Dict, Any
import yaml

from ..models.server_config import ProxyConfig


class ConfigManager:
    """配置管理器"""
    
    DEFAULT_CONFIG_FILE = "config.json"
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or self.DEFAULT_CONFIG_FILE
        self._config: Optional[ProxyConfig] = None
        
    def load(self) -> ProxyConfig:
        """加载配置"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                self._config = ProxyConfig(**data)
            except Exception as e:
                print(f"加载配置失败: {e}，使用默认配置")
                self._config = ProxyConfig()
        else:
            self._config = ProxyConfig()
            self.save()
        return self._config
    
    def save(self) -> bool:
        """保存配置"""
        try:
            if self._config is None:
                self._config = ProxyConfig()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self._config.model_dump(), f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"保存配置失败: {e}")
            return False
    
    def export_to_yaml(self, path: str) -> bool:
        """导出为YAML格式"""
        try:
            if self._config is None:
                return False
            
            with open(path, 'w', encoding='utf-8') as f:
                yaml.dump(self._config.model_dump(), f, allow_unicode=True, sort_keys=False)
            return True
        except Exception as e:
            print(f"导出YAML失败: {e}")
            return False
    
    def import_from_yaml(self, path: str) -> bool:
        """从YAML导入配置"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            self._config = ProxyConfig(**data)
            return True
        except Exception as e:
            print(f"导入YAML失败: {e}")
            return False
    
    def export_to_json(self, path: str) -> bool:
        """导出为JSON格式"""
        try:
            if self._config is None:
                return False
            
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self._config.model_dump(), f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"导出JSON失败: {e}")
            return False
    
    def import_from_json(self, path: str) -> bool:
        """从JSON导入配置"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self._config = ProxyConfig(**data)
            return True
        except Exception as e:
            print(f"导入JSON失败: {e}")
            return False
    
    def get_config(self) -> ProxyConfig:
        """获取当前配置"""
        if self._config is None:
            return self.load()
        return self._config
    
    def update_config(self, config: ProxyConfig) -> bool:
        """更新配置"""
        self._config = config
        return self.save()
    
    @property
    def config(self) -> ProxyConfig:
        """配置属性"""
        return self.get_config()
