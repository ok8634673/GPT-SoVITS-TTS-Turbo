"""
音频处理工具
"""
import wave
import io
import numpy as np
from typing import List, Optional, Tuple
import tempfile
import os


class AudioUtils:
    """音频处理工具类"""
    
    @staticmethod
    def merge_wav_files(audio_segments: List[bytes]) -> bytes:
        """
        合并多个WAV音频片段
        
        Args:
            audio_segments: WAV音频数据列表
            
        Returns:
            合并后的WAV音频数据
        """
        if not audio_segments:
            return b''
        
        if len(audio_segments) == 1:
            return audio_segments[0]
        
        # 解析所有音频片段
        audio_data_list = []
        sample_rate = None
        channels = None
        sample_width = None
        
        for segment in audio_segments:
            try:
                with wave.open(io.BytesIO(segment), 'rb') as wav:
                    if sample_rate is None:
                        sample_rate = wav.getframerate()
                        channels = wav.getnchannels()
                        sample_width = wav.getsampwidth()
                    
                    # 读取音频数据
                    frames = wav.readframes(wav.getnframes())
                    audio_data_list.append(frames)
            except Exception as e:
                print(f"解析音频片段失败: {e}")
                continue
        
        if not audio_data_list:
            return b''
        
        # 合并音频数据
        merged_data = b''.join(audio_data_list)
        
        # 创建新的WAV文件
        output = io.BytesIO()
        with wave.open(output, 'wb') as wav:
            wav.setnchannels(channels or 1)
            wav.setsampwidth(sample_width or 2)
            wav.setframerate(sample_rate or 32000)
            wav.writeframes(merged_data)
        
        return output.getvalue()
    
    @staticmethod
    def get_wav_info(audio_data: bytes) -> dict:
        """
        获取WAV音频信息
        
        Args:
            audio_data: WAV音频数据
            
        Returns:
            音频信息字典
        """
        try:
            with wave.open(io.BytesIO(audio_data), 'rb') as wav:
                return {
                    'channels': wav.getnchannels(),
                    'sample_width': wav.getsampwidth(),
                    'frame_rate': wav.getframerate(),
                    'frames': wav.getnframes(),
                    'duration': wav.getnframes() / wav.getframerate() if wav.getframerate() > 0 else 0
                }
        except Exception as e:
            return {'error': str(e)}
    
    @staticmethod
    def split_text(text: str, method: str = "cut4", max_length: int = 100) -> List[str]:
        """
        分割文本
        
        Args:
            text: 要分割的文本
            method: 分割方法 (cut4, sentence, paragraph)
            max_length: 最大长度
            
        Returns:
            分割后的文本列表
        """
        if not text:
            return []
        
        if method == "cut4":
            return AudioUtils._split_by_length(text, max_length)
        elif method == "sentence":
            return AudioUtils._split_by_sentence(text, max_length)
        elif method == "paragraph":
            return AudioUtils._split_by_paragraph(text, max_length)
        else:
            return AudioUtils._split_by_length(text, max_length)
    
    @staticmethod
    def _split_by_length(text: str, max_length: int) -> List[str]:
        """按长度分割文本"""
        segments = []
        current = ""
        
        for char in text:
            if len(current) >= max_length and char in '，。！？；,.!?;':
                current += char
                segments.append(current.strip())
                current = ""
            else:
                current += char
        
        if current.strip():
            segments.append(current.strip())
        
        return segments if segments else [text]
    
    @staticmethod
    def _split_by_sentence(text: str, max_length: int) -> List[str]:
        """按句子分割文本"""
        import re
        
        # 按标点符号分割
        sentences = re.split(r'([。！？；.!?;])', text)
        
        segments = []
        current = ""
        
        for i in range(0, len(sentences) - 1, 2):
            sentence = sentences[i] + (sentences[i + 1] if i + 1 < len(sentences) else "")
            
            if len(current) + len(sentence) <= max_length:
                current += sentence
            else:
                if current:
                    segments.append(current.strip())
                current = sentence
        
        # 处理最后一个
        if len(sentences) % 2 == 1:
            current += sentences[-1]
        
        if current.strip():
            segments.append(current.strip())
        
        return segments if segments else [text]
    
    @staticmethod
    def _split_by_paragraph(text: str, max_length: int) -> List[str]:
        """按段落分割文本"""
        paragraphs = text.split('\n')
        
        segments = []
        current = ""
        
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
                
            if len(current) + len(para) <= max_length:
                current += para + "\n"
            else:
                if current:
                    segments.append(current.strip())
                current = para + "\n"
        
        if current.strip():
            segments.append(current.strip())
        
        return segments if segments else [text]
    
    @staticmethod
    def save_temp_wav(audio_data: bytes) -> str:
        """
        保存临时WAV文件
        
        Args:
            audio_data: WAV音频数据
            
        Returns:
            临时文件路径
        """
        temp_file = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        temp_file.write(audio_data)
        temp_file.close()
        return temp_file.name
    
    @staticmethod
    def cleanup_temp_file(file_path: str):
        """清理临时文件"""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass
