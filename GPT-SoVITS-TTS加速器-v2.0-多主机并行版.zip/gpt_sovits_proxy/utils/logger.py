"""
日志管理工具
"""
import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional


class ColoredFormatter(logging.Formatter):
    """带颜色的日志格式化器"""
    
    # ANSI颜色代码
    COLORS = {
        'DEBUG': '\033[36m',      # 青色
        'INFO': '\033[32m',       # 绿色
        'WARNING': '\033[33m',    # 黄色
        'ERROR': '\033[31m',      # 红色
        'CRITICAL': '\033[35m',   # 紫色
        'RESET': '\033[0m'        # 重置
    }
    
    def format(self, record):
        # 保存原始levelname
        original_levelname = record.levelname
        
        # 添加颜色
        if hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
            color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
            record.levelname = f"{color}{record.levelname}{self.COLORS['RESET']}"
        
        # 格式化
        result = super().format(record)
        
        # 恢复原始levelname
        record.levelname = original_levelname
        
        return result


class LogManager:
    """日志管理器"""
    
    _instance = None
    _logger = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._logger is not None:
            return
            
        self._logger = logging.getLogger("GPTSoVITSProxy")
        self._logger.setLevel(logging.DEBUG)
        
        # 清除现有处理器
        self._logger.handlers.clear()
        
        # 控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)
        console_format = ColoredFormatter(
            '%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        self._logger.addHandler(console_handler)
        
        # 文件处理器
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        
        log_file = log_dir / f"proxy_{datetime.now().strftime('%Y%m%d')}.log"
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_format)
        self._logger.addHandler(file_handler)
        
        self._log_history = []
        self._max_history = 1000
    
    def get_logger(self) -> logging.Logger:
        """获取日志记录器"""
        return self._logger
    
    def add_to_history(self, level: str, message: str):
        """添加到历史记录"""
        self._log_history.append({
            'time': datetime.now().strftime('%H:%M:%S'),
            'level': level,
            'message': message
        })
        
        # 限制历史记录大小
        if len(self._log_history) > self._max_history:
            self._log_history = self._log_history[-self._max_history:]
    
    def get_history(self, level: Optional[str] = None, count: int = 100) -> list:
        """获取历史记录"""
        logs = self._log_history
        if level:
            logs = [log for log in logs if log['level'] == level]
        return logs[-count:]
    
    def clear_history(self):
        """清空历史记录"""
        self._log_history.clear()


# 全局日志管理器
_log_manager = LogManager()


def get_logger() -> logging.Logger:
    """获取日志记录器"""
    return _log_manager.get_logger()


def get_log_history(level: Optional[str] = None, count: int = 100) -> list:
    """获取日志历史"""
    return _log_manager.get_history(level, count)


def clear_log_history():
    """清空日志历史"""
    _log_manager.clear_history()


# 自定义日志处理器，用于捕获日志到历史记录
class HistoryHandler(logging.Handler):
    """历史记录处理器"""
    
    def emit(self, record):
        _log_manager.add_to_history(record.levelname, self.format(record))


# 添加历史记录处理器
_history_handler = HistoryHandler()
_history_handler.setLevel(logging.DEBUG)
get_logger().addHandler(_history_handler)
