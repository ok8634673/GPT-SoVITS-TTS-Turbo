"""
TTS测试对话框 - 文本朗读播放调试界面
"""
import customtkinter as ctk
from tkinter import messagebox, filedialog
import requests
import threading
import time
import os
import pygame
import io

from .theme import ThemeManager, Fonts
from ..models.server_config import TTSRequest, ProxyConfig, ServerStatus


class TTSTestDialog(ctk.CTkToplevel):
    """TTS测试对话框"""

    def __init__(self, parent, config: ProxyConfig):
        super().__init__(parent)

        self.config = config
        self.audio_data = None
        self.temp_audio_file = None

        # 初始化pygame mixer
        try:
            pygame.mixer.init()
        except Exception as e:
            print(f"Warning: Failed to initialize pygame mixer: {e}")

        # 缓存文件夹路径（从配置中获取）
        self.cache_folder = self.config.ui_settings.cache_folder or "cache"
        # 确保缓存文件夹存在
        os.makedirs(self.cache_folder, exist_ok=True)

        # 窗口设置
        self.title("TTS测试 - 文本朗读调试")
        self.geometry("700x700")
        self.minsize(600, 600)
        
        # 居中显示
        self.transient(parent)
        self.update_idletasks()
        x = (self.winfo_screenwidth() - self.winfo_width()) // 2
        y = (self.winfo_screenheight() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
        
        self._create_ui()
        
    def _create_ui(self):
        """创建UI界面"""
        # 主框架
        main_frame = ctk.CTkFrame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 标题
        title = ctk.CTkLabel(
            main_frame,
            text="🎙️ TTS 文本朗读测试",
            font=Fonts.HEADER
        )
        title.pack(pady=(0, 20))
        
        # 文本输入区域
        input_frame = ctk.CTkFrame(main_frame)
        input_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        ctk.CTkLabel(input_frame, text="输入文本:", font=Fonts.SUBHEADER).pack(anchor="w", padx=10, pady=5)
        
        self.text_input = ctk.CTkTextbox(input_frame, font=Fonts.BODY_LARGE, height=120)
        self.text_input.pack(fill="both", expand=True, padx=10, pady=5)
        self.text_input.insert("1.0", "你好，我是可莉！很高兴为你服务。")
        
        # 快捷文本按钮
        quick_frame = ctk.CTkFrame(input_frame, fg_color="transparent")
        quick_frame.pack(fill="x", padx=10, pady=5)
        
        quick_texts = [
            "你好，我是可莉！",
            "今天天气真不错！",
            "我要去冒险了！",
            "你最喜欢什么？"
        ]
        
        for text in quick_texts:
            ctk.CTkButton(
                quick_frame,
                text=text[:8] + "..." if len(text) > 8 else text,
                font=Fonts.SMALL,
                width=100,
                height=28,
                command=lambda t=text: self._set_quick_text(t)
            ).pack(side="left", padx=2)
        
        # 服务器选择区域
        server_frame = ctk.CTkFrame(main_frame)
        server_frame.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(server_frame, text="服务器选择", font=Fonts.SUBHEADER).pack(anchor="w", padx=10, pady=5)
        
        # 服务器下拉选择
        server_frame_inner = ctk.CTkFrame(server_frame, fg_color="transparent")
        server_frame_inner.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(server_frame_inner, text="选择服务器:", font=Fonts.BODY, width=100).pack(side="left")
        
        self.server_var = ctk.StringVar()
        self.server_combo = ctk.CTkComboBox(server_frame_inner, variable=self.server_var, width=300)
        self.server_combo.pack(side="left", fill="x", expand=True, padx=5)
        
        # 刷新服务器列表按钮
        ctk.CTkButton(
            server_frame_inner,
            text="🔄",
            width=30,
            command=self._refresh_server_list
        ).pack(side="left", padx=5)
        
        # 刷新服务器列表
        self._update_server_list()
        
        # 参数设置区域
        params_frame = ctk.CTkFrame(main_frame)
        params_frame.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkLabel(params_frame, text="参数设置", font=Fonts.SUBHEADER).pack(anchor="w", padx=10, pady=5)
        
        # 参数网格
        params_grid = ctk.CTkFrame(params_frame, fg_color="transparent")
        params_grid.pack(fill="x", padx=10, pady=5)
        params_grid.grid_columnconfigure((0, 1, 2, 3), weight=1)
        
        # 语速
        ctk.CTkLabel(params_grid, text="语速:", font=Fonts.BODY).grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.speed_var = ctk.StringVar(value="1.0")
        speed_combo = ctk.CTkComboBox(
            params_grid,
            values=["0.5", "0.8", "1.0", "1.2", "1.5", "2.0"],
            variable=self.speed_var,
            width=80
        )
        speed_combo.grid(row=0, column=1, padx=5, pady=5, sticky="w")
        
        # 温度
        ctk.CTkLabel(params_grid, text="温度:", font=Fonts.BODY).grid(row=0, column=2, padx=5, pady=5, sticky="e")
        self.temp_var = ctk.StringVar(value="1.0")
        temp_combo = ctk.CTkComboBox(
            params_grid,
            values=["0.3", "0.5", "0.8", "1.0", "1.2", "1.5"],
            variable=self.temp_var,
            width=80
        )
        temp_combo.grid(row=0, column=3, padx=5, pady=5, sticky="w")
        
        # Top-K
        ctk.CTkLabel(params_grid, text="Top-K:", font=Fonts.BODY).grid(row=1, column=0, padx=5, pady=5, sticky="e")
        self.topk_var = ctk.StringVar(value="5")
        topk_combo = ctk.CTkComboBox(
            params_grid,
            values=["1", "3", "5", "10", "20", "50"],
            variable=self.topk_var,
            width=80
        )
        topk_combo.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        
        # Top-P
        ctk.CTkLabel(params_grid, text="Top-P:", font=Fonts.BODY).grid(row=1, column=2, padx=5, pady=5, sticky="e")
        self.topp_var = ctk.StringVar(value="1.0")
        topp_combo = ctk.CTkComboBox(
            params_grid,
            values=["0.1", "0.5", "0.8", "0.9", "1.0"],
            variable=self.topp_var,
            width=80
        )
        topp_combo.grid(row=1, column=3, padx=5, pady=5, sticky="w")
        
        # 进度条
        self.progress_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        self.progress_frame.pack(fill="x", padx=10, pady=10)
        
        self.progress_label = ctk.CTkLabel(self.progress_frame, text="就绪", font=Fonts.SMALL)
        self.progress_label.pack(anchor="w")
        
        self.progress_bar = ctk.CTkProgressBar(self.progress_frame)
        self.progress_bar.pack(fill="x", pady=5)
        self.progress_bar.set(0)
        
        # 操作按钮区域
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=10)
        
        self.generate_btn = ctk.CTkButton(
            btn_frame,
            text="🎙️ 生成语音",
            font=Fonts.BODY,
            height=40,
            command=self._generate_speech
        )
        self.generate_btn.pack(side="left", padx=5)
        
        self.play_btn = ctk.CTkButton(
            btn_frame,
            text="▶ 播放",
            font=Fonts.BODY,
            height=40,
            state="disabled",
            command=self._play_audio
        )
        self.play_btn.pack(side="left", padx=5)
        
        self.save_btn = ctk.CTkButton(
            btn_frame,
            text="💾 保存音频",
            font=Fonts.BODY,
            height=40,
            state="disabled",
            command=self._save_audio
        )
        self.save_btn.pack(side="left", padx=5)
        
        ctk.CTkButton(
            btn_frame,
            text="关闭",
            font=Fonts.BODY,
            height=40,
            fg_color="gray",
            command=self.destroy
        ).pack(side="right", padx=5)
        
    def _set_quick_text(self, text: str):
        """设置快捷文本"""
        self.text_input.delete("1.0", "end")
        self.text_input.insert("1.0", text)
        
    def _update_server_list(self):
        """更新服务器列表"""
        servers = []
        server_map = {}
        
        for server in self.config.servers:
            if server.enabled:
                status = "在线" if server.status == ServerStatus.ONLINE else "离线"
                display_text = f"{server.name} ({server.address}:{server.port}) - {status}"
                servers.append(display_text)
                server_map[display_text] = server
        
        # 添加到下拉框
        self.server_combo.configure(values=servers)
        
        # 默认选择第一个在线服务器
        if servers:
            for s in servers:
                if "在线" in s:
                    self.server_var.set(s)
                    break
            if not self.server_var.get() and servers:
                self.server_var.set(servers[0])
        
        self.server_map = server_map
        
    def _refresh_server_list(self):
        """刷新服务器列表"""
        # 从主窗口获取最新配置
        from .main_window import MainWindow
        if isinstance(self.master, MainWindow):
            # 重新加载配置
            self.config = self.master.proxy_config
            # 更新服务器列表
            self._update_server_list()
            # 显示刷新成功
            self.progress_label.configure(text="✅ 服务器列表已刷新")
            self.after(2000, lambda: self.progress_label.configure(text="就绪"))
        
    def _generate_speech(self):
        """生成语音"""
        text = self.text_input.get("1.0", "end").strip()
        
        if not text:
            messagebox.showwarning("警告", "请输入要合成的文本")
            return
            
        # 禁用按钮
        self.generate_btn.configure(state="disabled", text="生成中...")
        self.progress_bar.set(0)
        self.progress_label.configure(text="正在生成语音...")
        
        # 在新线程中生成
        thread = threading.Thread(target=self._do_generate, args=(text,), daemon=True)
        thread.start()
        
    def _do_generate(self, text: str):
        """执行生成（在线程中）"""
        try:
            # 构建请求
            url = f"http://localhost:{self.config.server_port}/tts"
            
            # 获取用户选择的服务器
            selected_server_name = self.server_var.get()
            default_server = self.server_map.get(selected_server_name)
            
            # 如果没有选择服务器，获取第一个在线的服务器
            if not default_server:
                for server in self.config.servers:
                    if server.enabled and server.status == ServerStatus.ONLINE:
                        default_server = server
                        break
            
            # 如果没有在线服务器，尝试获取第一个启用的服务器
            if not default_server:
                for server in self.config.servers:
                    if server.enabled:
                        default_server = server
                        break
            
            # 检查是否有服务器
            if not default_server:
                self.after(0, lambda: self._on_generate_error("没有可用的服务器"))
                return
                    
            payload = {
                "text": text,
                "text_lang": "auto",
                "speed_factor": float(self.speed_var.get()),
                "temperature": float(self.temp_var.get()),
                "top_k": int(self.topk_var.get()),
                "top_p": float(self.topp_var.get()),
                "text_split_method": "cut4",
                "batch_size": 1
            }
            
            # 如果有默认服务器，使用其参考音频配置和服务器ID
            if default_server:
                payload["ref_audio_path"] = default_server.ref_audio_path
                payload["prompt_text"] = default_server.prompt_text
                payload["prompt_lang"] = default_server.prompt_lang
                payload["server_id"] = default_server.id
                
            # 模拟进度
            for i in range(10):
                time.sleep(0.1)
                self.after(0, lambda v=i/10: self.progress_bar.set(v))
                
            # 发送请求
            print(f"发送TTS请求到: {url}")
            print(f"请求参数: {payload}")
            response = requests.post(url, json=payload, timeout=300)
            print(f"响应状态码: {response.status_code}")
            
            if response.status_code == 200:
                self.audio_data = response.content
                self.after(0, self._on_generate_success)
            else:
                error_msg = f"生成失败: HTTP {response.status_code}"
                try:
                    error_data = response.json()
                    if "detail" in error_data:
                        error_msg = error_data["detail"]
                except:
                    pass
                self.after(0, lambda: self._on_generate_error(error_msg))
                
        except requests.exceptions.ConnectionError:
            self.after(0, lambda: self._on_generate_error("无法连接到服务，请确保服务已启动"))
        except Exception as e:
            self.after(0, lambda: self._on_generate_error(str(e)))
            
    def _on_generate_success(self):
        """生成成功回调"""
        self.progress_bar.set(1)
        self.generate_btn.configure(state="normal", text="🎙️ 生成语音")
        self.play_btn.configure(state="normal")
        self.save_btn.configure(state="normal")

        # 显示音频信息（不显示弹窗，只在状态栏显示）
        if self.audio_data:
            size_kb = len(self.audio_data) / 1024
            self.progress_label.configure(text=f"✓ 生成完成 (大小: {size_kb:.1f} KB)")

            # 保存到缓存文件夹
            self._save_to_cache()

        # 自动播放音频
        self._play_audio()
            
    def _on_generate_error(self, error: str):
        """生成失败回调"""
        self.progress_bar.set(0)
        self.progress_label.configure(text=f"✗ 生成失败")
        self.generate_btn.configure(state="normal", text="🎙️ 生成语音")
        messagebox.showerror("错误", f"生成失败:\n{error}")
        
    def _play_audio(self):
        """播放音频"""
        if not self.audio_data:
            return

        try:
            # 停止之前的播放
            pygame.mixer.music.stop()

            # 将音频数据加载到pygame
            audio_stream = io.BytesIO(self.audio_data)
            pygame.mixer.music.load(audio_stream)
            pygame.mixer.music.play()

            self.progress_label.configure(text="🔊 正在播放...")
            self.after(100, self._check_playback_status)

        except Exception as e:
            messagebox.showerror("错误", f"播放失败: {e}")

    def _check_playback_status(self):
        """检查播放状态"""
        if not pygame.mixer.music.get_busy():
            self.progress_label.configure(text="✓ 播放完成")
        else:
            self.after(100, self._check_playback_status)

    def _save_to_cache(self):
        """保存音频到缓存文件夹"""
        if not self.audio_data:
            return

        try:
            # 获取当前时间
            import datetime
            current_time = datetime.datetime.now()
            time_str = current_time.strftime("%Y%m%d_%H%M%S")

            # 获取服务器名称
            server_name = "unknown"
            selected_server_name = self.server_var.get()
            if selected_server_name in self.server_map:
                server = self.server_map[selected_server_name]
                server_name = server.name

            # 获取输入文本
            input_text = self.text_input.get("1.0", "end").strip()
            # 截取前20个字符作为文件名的一部分
            short_text = input_text[:20]

            # 清理特殊字符
            def clean_filename(text):
                return "".join(c for c in text if c.isalnum() or c in "_- ").strip()

            safe_text = clean_filename(short_text)
            safe_server_name = clean_filename(server_name)

            # 生成文件名
            filename = f"{safe_text}-{safe_server_name}-{time_str}.wav"
            filepath = os.path.join(self.cache_folder, filename)

            # 保存文件
            with open(filepath, "wb") as f:
                f.write(self.audio_data)

            print(f"音频已保存到缓存: {filepath}")

        except Exception as e:
            print(f"保存到缓存失败: {e}")
            
    def _save_audio(self):
        """保存音频"""
        if not self.audio_data:
            return
            
        file_path = filedialog.asksaveasfilename(
            title="保存音频",
            defaultextension=".wav",
            filetypes=[("WAV文件", "*.wav"), ("所有文件", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, "wb") as f:
                    f.write(self.audio_data)
                messagebox.showinfo("成功", f"音频已保存到:\n{file_path}")
            except Exception as e:
                messagebox.showerror("错误", f"保存失败: {e}")
                
    def destroy(self):
        """销毁窗口"""
        # 清理临时文件
        if self.temp_audio_file and os.path.exists(self.temp_audio_file):
            try:
                os.remove(self.temp_audio_file)
            except:
                pass
        super().destroy()
