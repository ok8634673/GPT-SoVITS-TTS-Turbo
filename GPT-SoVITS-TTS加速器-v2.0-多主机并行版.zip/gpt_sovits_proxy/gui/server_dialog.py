"""
服务器配置对话框
"""
import customtkinter as ctk
from tkinter import messagebox, filedialog
from typing import Optional, Callable

from .theme import ThemeManager, Fonts
from ..models.server_config import ServerConfig, LoadBalanceStrategy


class ServerDialog(ctk.CTkToplevel):
    """服务器配置对话框"""
    
    def __init__(self, parent, server: Optional[ServerConfig], on_save: Callable):
        super().__init__(parent)
        
        self.server = server
        self.on_save = on_save
        self.result: Optional[ServerConfig] = None
        
        # 窗口设置
        self.title("编辑服务器" if server else "添加服务器")
        self.geometry("550x650")
        self.resizable(False, False)
        
        # 居中显示
        self.transient(parent)
        self.update_idletasks()
        x = (self.winfo_screenwidth() - self.winfo_width()) // 2
        y = (self.winfo_screenheight() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
        
        self._create_ui()
        
        if server:
            self._load_server_data()
            
    def _create_ui(self):
        """创建UI"""
        # 主框架
        main_frame = ctk.CTkFrame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 标题
        title = ctk.CTkLabel(
            main_frame,
            text="编辑服务器" if self.server else "添加服务器",
            font=Fonts.HEADER
        )
        title.pack(pady=(0, 20))
        
        # 表单区域
        form_frame = ctk.CTkScrollableFrame(main_frame)
        form_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # 基本信息
        self._create_section(form_frame, "基本信息")
        
        self.name_var = ctk.StringVar()
        self._create_form_row(form_frame, "服务器名称*:", self.name_var, "例如：服务器1")
        
        self.address_var = ctk.StringVar()
        self._create_form_row(form_frame, "服务器地址*:", self.address_var, "例如：192.168.1.1")
        
        self.port_var = ctk.StringVar(value="9880")
        self._create_form_row(form_frame, "API端口*:", self.port_var, "例如：9880")
        
        # 参考音频配置
        self._create_section(form_frame, "参考音频配置")
        
        self.ref_audio_var = ctk.StringVar()
        self._create_form_row_with_browse(form_frame, "参考音频路径*:", self.ref_audio_var, 
                                         "选择参考音频文件", self._browse_audio)
        
        self.prompt_text_var = ctk.StringVar()
        self._create_form_row(form_frame, "参考音频文本*:", self.prompt_text_var, "参考音频对应的文本内容")
        
        self.prompt_lang_var = ctk.StringVar(value="zh")
        self._create_form_row(form_frame, "参考音频语言*:", self.prompt_lang_var, "zh/en/ja等")
        
        # 高级设置
        self._create_section(form_frame, "高级设置")
        
        self.weight_var = ctk.StringVar(value="1")
        self._create_form_row(form_frame, "权重:", self.weight_var, "用于加权轮询")
        
        self.max_conn_var = ctk.StringVar(value="10")
        self._create_form_row(form_frame, "最大连接数:", self.max_conn_var, "最大并发连接数")
        
        self.enabled_var = ctk.BooleanVar(value=True)
        enabled_check = ctk.CTkCheckBox(form_frame, text="启用此服务器", variable=self.enabled_var)
        enabled_check.pack(fill="x", padx=10, pady=10)
        
        # 按钮区域
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=(20, 10))
        
        ctk.CTkButton(
            btn_frame,
            text="保存",
            font=Fonts.BODY,
            width=120,
            height=35,
            command=self._save
        ).pack(side="right", padx=5)
        
        ctk.CTkButton(
            btn_frame,
            text="取消",
            font=Fonts.BODY,
            width=120,
            height=35,
            fg_color="gray",
            command=self.destroy
        ).pack(side="right", padx=5)
        
        # 测试连接按钮
        ctk.CTkButton(
            btn_frame,
            text="测试连接",
            font=Fonts.BODY,
            width=120,
            height=35,
            command=self._test_connection
        ).pack(side="left", padx=5)
        
    def _create_section(self, parent, title: str):
        """创建分组标题"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", padx=10, pady=(15, 5))
        
        ctk.CTkLabel(frame, text=title, font=Fonts.SUBHEADER).pack(anchor="w")
        ctk.CTkFrame(parent, height=1, fg_color="gray").pack(fill="x", padx=10, pady=5)
        
    def _create_form_row(self, parent, label: str, variable, placeholder: str = ""):
        """创建表单行"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(frame, text=label, font=Fonts.BODY, width=120).pack(side="left")
        
        entry = ctk.CTkEntry(frame, textvariable=variable, font=Fonts.BODY, placeholder_text=placeholder)
        entry.pack(side="left", fill="x", expand=True, padx=(10, 0))
        
    def _create_form_row_with_browse(self, parent, label: str, variable, btn_text: str, command):
        """创建带浏览按钮的表单行"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(frame, text=label, font=Fonts.BODY, width=120).pack(side="left")
        
        entry = ctk.CTkEntry(frame, textvariable=variable, font=Fonts.BODY)
        entry.pack(side="left", fill="x", expand=True, padx=(10, 5))
        
        ctk.CTkButton(frame, text=btn_text, width=80, command=command).pack(side="right")
        
    def _browse_audio(self):
        """浏览音频文件"""
        file_path = filedialog.askopenfilename(
            title="选择参考音频文件",
            filetypes=[("WAV文件", "*.wav"), ("所有文件", "*.*")]
        )
        if file_path:
            self.ref_audio_var.set(file_path)
            
    def _load_server_data(self):
        """加载服务器数据"""
        if self.server:
            self.name_var.set(self.server.name)
            self.address_var.set(self.server.address)
            self.port_var.set(str(self.server.port))
            self.ref_audio_var.set(self.server.ref_audio_path)
            self.prompt_text_var.set(self.server.prompt_text)
            self.prompt_lang_var.set(self.server.prompt_lang)
            self.weight_var.set(str(self.server.weight))
            self.max_conn_var.set(str(self.server.max_connections))
            self.enabled_var.set(self.server.enabled)
            
    def _validate(self) -> bool:
        """验证输入"""
        if not self.name_var.get().strip():
            messagebox.showerror("错误", "请输入服务器名称")
            return False
            
        if not self.address_var.get().strip():
            messagebox.showerror("错误", "请输入服务器地址")
            return False
            
        try:
            port = int(self.port_var.get())
            if not (1 <= port <= 65535):
                raise ValueError()
        except ValueError:
            messagebox.showerror("错误", "端口号必须是1-65535之间的整数")
            return False
            
        if not self.ref_audio_var.get().strip():
            messagebox.showerror("错误", "请选择参考音频文件")
            return False
            
        if not self.prompt_text_var.get().strip():
            messagebox.showerror("错误", "请输入参考音频文本")
            return False
            
        return True
        
    def _save(self):
        """保存服务器配置"""
        if not self._validate():
            return
            
        # 创建或更新服务器配置
        if self.server:
            server = self.server
        else:
            server = ServerConfig(
                name="",
                address="",
                ref_audio_path="",
                prompt_text=""
            )
            
        server.name = self.name_var.get().strip()
        server.address = self.address_var.get().strip()
        server.port = int(self.port_var.get())
        server.ref_audio_path = self.ref_audio_var.get().strip()
        server.prompt_text = self.prompt_text_var.get().strip()
        server.prompt_lang = self.prompt_lang_var.get().strip()
        server.weight = int(self.weight_var.get() or 1)
        server.max_connections = int(self.max_conn_var.get() or 10)
        server.enabled = self.enabled_var.get()
        
        self.result = server
        self.on_save(server)
        self.destroy()
        
    def _test_connection(self):
        """测试连接"""
        address = self.address_var.get().strip()
        port = self.port_var.get()
        
        if not address or not port:
            messagebox.showwarning("警告", "请先填写服务器地址和端口")
            return
            
        try:
            import asyncio
            import aiohttp
            
            async def test():
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.get(
                            f"http://{address}:{port}",
                            timeout=aiohttp.ClientTimeout(total=5)
                        ) as response:
                            if response.status in (200, 404):
                                return True, f"连接成功 (HTTP {response.status})"
                            else:
                                return False, f"HTTP {response.status}"
                except Exception as e:
                    return False, str(e)
                    
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            success, message = loop.run_until_complete(test())
            loop.close()
            
            if success:
                messagebox.showinfo("测试结果", f"✓ 连接成功\n{message}")
            else:
                messagebox.showerror("测试结果", f"✗ 连接失败\n{message}")
                
        except Exception as e:
            messagebox.showerror("错误", f"测试失败: {e}")
