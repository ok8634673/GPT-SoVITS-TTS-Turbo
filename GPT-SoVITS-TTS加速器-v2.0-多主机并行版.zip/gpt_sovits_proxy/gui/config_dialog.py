"""
配置管理对话框
"""
import customtkinter as ctk
from tkinter import messagebox, filedialog
from typing import Callable

from .theme import ThemeManager, Fonts
from ..utils.config import ConfigManager
from ..models.server_config import LoadBalanceStrategy, NodeMode


class ConfigDialog(ctk.CTkToplevel):
    """配置管理对话框"""
    
    def __init__(self, parent, config_manager: ConfigManager, on_saved: Callable):
        super().__init__(parent)
        
        self.config_manager = config_manager
        self.on_saved = on_saved
        self.config = config_manager.get_config()
        
        # 窗口设置
        self.title("配置管理")
        self.geometry("700x700")
        self.minsize(600, 600)
        
        # 居中显示
        self.transient(parent)
        self.update_idletasks()
        x = (self.winfo_screenwidth() - self.winfo_width()) // 2
        y = (self.winfo_screenheight() - self.winfo_height()) // 2
        self.geometry(f"+{x}+{y}")
        
        self._create_ui()
        self._load_config()
        
    def _create_ui(self):
        """创建UI"""
        # 主框架
        main_frame = ctk.CTkFrame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # 标题
        title = ctk.CTkLabel(main_frame, text="⚙️ 配置管理", font=Fonts.HEADER)
        title.pack(pady=(0, 20))
        
        # 创建标签页
        self.tabview = ctk.CTkTabview(main_frame)
        self.tabview.pack(fill="both", expand=True, padx=10, pady=10)
        
        # 基本设置标签页
        self._create_basic_tab()
        
        # 负载均衡标签页
        self._create_loadbalance_tab()
        
        # 集群设置标签页
        self._create_cluster_tab()
        
        # UI设置标签页
        self._create_ui_tab()
        
        # 导入导出按钮区域
        io_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        io_frame.pack(fill="x", padx=10, pady=(10, 5))
        
        ctk.CTkButton(
            io_frame,
            text="📥 导入配置",
            font=Fonts.BODY,
            command=self._import_config
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            io_frame,
            text="📤 导出配置",
            font=Fonts.BODY,
            command=self._export_config
        ).pack(side="left", padx=5)
        
        # 保存取消按钮
        btn_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=10, pady=(5, 10))
        
        ctk.CTkButton(
            btn_frame,
            text="保存",
            font=Fonts.BODY,
            width=120,
            height=35,
            command=self._save
        ).pack(side="right", padx=5)
        
        ctk.CTkButton(
            btn_frame,
            text="取消",
            font=Fonts.BODY,
            width=120,
            height=35,
            fg_color="gray",
            command=self.destroy
        ).pack(side="right", padx=5)
        
    def _create_basic_tab(self):
        """创建基本设置标签页"""
        tab = self.tabview.add("基本设置")
        
        # 服务设置
        self._create_section(tab, "服务设置")
        
        self.server_name_var = ctk.StringVar()
        self._create_form_row(tab, "服务器名称:", self.server_name_var)
        
        self.host_var = ctk.StringVar()
        self._create_form_row(tab, "绑定主机:", self.host_var)
        
        self.port_var = ctk.StringVar()
        self._create_form_row(tab, "服务端口:", self.port_var)
        
        # 超时设置
        self._create_section(tab, "超时设置")
        
        self.timeout_var = ctk.StringVar()
        self._create_form_row(tab, "请求超时(秒):", self.timeout_var)
        
        self.retries_var = ctk.StringVar()
        self._create_form_row(tab, "最大重试次数:", self.retries_var)
        
        self.retry_delay_var = ctk.StringVar()
        self._create_form_row(tab, "重试延迟(秒):", self.retry_delay_var)
        
    def _create_loadbalance_tab(self):
        """创建负载均衡标签页"""
        tab = self.tabview.add("负载均衡")
        
        self._create_section(tab, "负载均衡策略")
        
        self.lb_strategy_var = ctk.StringVar(value="round-robin")
        
        strategies = [
            ("轮询 (Round-Robin)", "round-robin"),
            ("最少连接 (Least Connections)", "least-connections"),
            ("加权轮询 (Weighted Round-Robin)", "weighted-round-robin")
        ]
        
        for text, value in strategies:
            ctk.CTkRadioButton(
                tab,
                text=text,
                variable=self.lb_strategy_var,
                value=value,
                font=Fonts.BODY
            ).pack(anchor="w", padx=20, pady=5)
            
    def _create_cluster_tab(self):
        """创建集群设置标签页"""
        tab = self.tabview.add("集群设置")
        
        self._create_section(tab, "集群模式")
        
        self.cluster_enabled_var = ctk.BooleanVar()
        enabled_check = ctk.CTkCheckBox(
            tab,
            text="启用集群模式",
            variable=self.cluster_enabled_var,
            font=Fonts.BODY,
            command=self._on_cluster_toggle
        )
        enabled_check.pack(anchor="w", padx=20, pady=10)
        
        self.cluster_frame = ctk.CTkFrame(tab, fg_color="transparent")
        self.cluster_frame.pack(fill="x", padx=10, pady=5)
        
        self.node_mode_var = ctk.StringVar(value="standalone")
        
        ctk.CTkLabel(self.cluster_frame, text="节点模式:", font=Fonts.BODY).pack(anchor="w", padx=10, pady=5)
        
        modes = [
            ("独立模式", "standalone"),
            ("主节点", "master"),
            ("从节点", "slave")
        ]
        
        for text, value in modes:
            ctk.CTkRadioButton(
                self.cluster_frame,
                text=text,
                variable=self.node_mode_var,
                value=value,
                font=Fonts.BODY
            ).pack(anchor="w", padx=20, pady=2)
            
        self.node_name_var = ctk.StringVar()
        self._create_form_row(self.cluster_frame, "节点名称:", self.node_name_var)
        
        self.cluster_port_var = ctk.StringVar()
        self._create_form_row(self.cluster_frame, "集群通讯端口:", self.cluster_port_var)
        
        self.master_addr_var = ctk.StringVar()
        self._create_form_row(self.cluster_frame, "主节点地址:", self.master_addr_var)
        
        self.master_port_var = ctk.StringVar()
        self._create_form_row(self.cluster_frame, "主节点端口:", self.master_port_var)
        
    def _create_ui_tab(self):
        """创建UI设置标签页"""
        tab = self.tabview.add("界面设置")
        
        self._create_section(tab, "外观")
        
        self.theme_var = ctk.StringVar(value="dark")
        
        ctk.CTkLabel(tab, text="主题:", font=Fonts.BODY).pack(anchor="w", padx=20, pady=5)
        
        ctk.CTkRadioButton(
            tab,
            text="深色主题",
            variable=self.theme_var,
            value="dark",
            font=Fonts.BODY
        ).pack(anchor="w", padx=30, pady=2)
        
        ctk.CTkRadioButton(
            tab,
            text="浅色主题",
            variable=self.theme_var,
            value="light",
            font=Fonts.BODY
        ).pack(anchor="w", padx=30, pady=2)
        
        self._create_section(tab, "行为")
        
        self.auto_save_var = ctk.BooleanVar()
        ctk.CTkCheckBox(
            tab,
            text="自动保存配置",
            variable=self.auto_save_var,
            font=Fonts.BODY
        ).pack(anchor="w", padx=20, pady=5)

        # 缓存设置
        self._create_section(tab, "缓存设置")

        cache_frame = ctk.CTkFrame(tab, fg_color="transparent")
        cache_frame.pack(fill="x", padx=20, pady=5)

        ctk.CTkLabel(cache_frame, text="缓存文件夹:", font=Fonts.BODY, width=150).pack(side="left")

        self.cache_folder_var = ctk.StringVar()
        cache_entry = ctk.CTkEntry(cache_frame, textvariable=self.cache_folder_var, font=Fonts.BODY)
        cache_entry.pack(side="left", fill="x", expand=True, padx=(10, 0))

        ctk.CTkButton(
            cache_frame,
            text="浏览",
            font=Fonts.SMALL,
            width=60,
            command=self._browse_cache_folder
        ).pack(side="left", padx=(10, 0))

        # 启动设置
        self._create_section(tab, "启动设置")

        self.auto_start_service_var = ctk.BooleanVar()
        ctk.CTkCheckBox(
            tab,
            text="自动启动服务",
            variable=self.auto_start_service_var,
            font=Fonts.BODY
        ).pack(anchor="w", padx=20, pady=5)

        self.auto_start_on_boot_var = ctk.BooleanVar()
        ctk.CTkCheckBox(
            tab,
            text="开机自启",
            variable=self.auto_start_on_boot_var,
            font=Fonts.BODY
        ).pack(anchor="w", padx=20, pady=5)
        
    def _create_section(self, parent, title: str):
        """创建分组标题"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", padx=10, pady=(15, 5))
        
        ctk.CTkLabel(frame, text=title, font=Fonts.SUBHEADER).pack(anchor="w")
        ctk.CTkFrame(parent, height=1, fg_color="gray").pack(fill="x", padx=10, pady=5)
        
    def _create_form_row(self, parent, label: str, variable):
        """创建表单行"""
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(frame, text=label, font=Fonts.BODY, width=150).pack(side="left")
        
        entry = ctk.CTkEntry(frame, textvariable=variable, font=Fonts.BODY)
        entry.pack(side="left", fill="x", expand=True, padx=(10, 0))
        
    def _on_cluster_toggle(self):
        """集群启用切换"""
        if self.cluster_enabled_var.get():
            self.cluster_frame.configure(fg_color="transparent")
        else:
            self.cluster_frame.configure(fg_color="gray20")

    def _browse_cache_folder(self):
        """浏览缓存文件夹"""
        folder_path = filedialog.askdirectory(
            title="选择缓存文件夹",
            initialdir=self.cache_folder_var.get() or "cache"
        )
        if folder_path:
            self.cache_folder_var.set(folder_path)
            
    def _load_config(self):
        """加载配置到UI"""
        # 基本设置
        self.server_name_var.set(self.config.server_name)
        self.host_var.set(self.config.host)
        self.port_var.set(str(self.config.server_port))
        self.timeout_var.set(str(self.config.request_timeout))
        self.retries_var.set(str(self.config.max_retries))
        self.retry_delay_var.set(str(self.config.retry_delay))
        
        # 负载均衡
        self.lb_strategy_var.set(self.config.load_balance_strategy.value)
        
        # 集群设置
        self.cluster_enabled_var.set(self.config.cluster.enabled)
        self.node_mode_var.set(self.config.cluster.mode.value)
        self.node_name_var.set(self.config.cluster.node_name)
        self.cluster_port_var.set(str(self.config.cluster.cluster_port))
        self.master_addr_var.set(self.config.cluster.master_address or "")
        self.master_port_var.set(str(self.config.cluster.master_port or ""))
        
        # UI设置
        self.theme_var.set(self.config.ui_settings.theme)
        self.auto_save_var.set(self.config.ui_settings.auto_save)
        self.cache_folder_var.set(self.config.ui_settings.cache_folder)
        self.auto_start_service_var.set(self.config.ui_settings.auto_start_service)
        self.auto_start_on_boot_var.set(self.config.ui_settings.auto_start_on_boot)
        
        self._on_cluster_toggle()
        
    def _save(self):
        """保存配置"""
        try:
            # 基本设置
            self.config.server_name = self.server_name_var.get()
            self.config.host = self.host_var.get()
            self.config.server_port = int(self.port_var.get())
            self.config.request_timeout = int(self.timeout_var.get())
            self.config.max_retries = int(self.retries_var.get())
            self.config.retry_delay = float(self.retry_delay_var.get())
            
            # 负载均衡
            self.config.load_balance_strategy = LoadBalanceStrategy(self.lb_strategy_var.get())
            
            # 集群设置
            self.config.cluster.enabled = self.cluster_enabled_var.get()
            self.config.cluster.mode = NodeMode(self.node_mode_var.get())
            self.config.cluster.node_name = self.node_name_var.get()
            self.config.cluster.cluster_port = int(self.cluster_port_var.get())
            self.config.cluster.master_address = self.master_addr_var.get() or None
            master_port = self.master_port_var.get()
            self.config.cluster.master_port = int(master_port) if master_port else None
            
            # UI设置
            self.config.ui_settings.theme = self.theme_var.get()
            self.config.ui_settings.auto_save = self.auto_save_var.get()
            self.config.ui_settings.cache_folder = self.cache_folder_var.get()
            self.config.ui_settings.auto_start_service = self.auto_start_service_var.get()
            self.config.ui_settings.auto_start_on_boot = self.auto_start_on_boot_var.get()
            
            # 保存到文件
            if self.config_manager.update_config(self.config):
                messagebox.showinfo("成功", "配置已保存")
                self.on_saved()
                self.destroy()
            else:
                messagebox.showerror("错误", "保存配置失败")
                
        except ValueError as e:
            messagebox.showerror("错误", f"输入格式错误: {e}")
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {e}")
            
    def _import_config(self):
        """导入配置"""
        file_path = filedialog.askopenfilename(
            title="导入配置",
            filetypes=[
                ("JSON文件", "*.json"),
                ("YAML文件", "*.yaml;*.yml"),
                ("所有文件", "*.*")
            ]
        )
        
        if not file_path:
            return
            
        try:
            if file_path.endswith('.yaml') or file_path.endswith('.yml'):
                success = self.config_manager.import_from_yaml(file_path)
            else:
                success = self.config_manager.import_from_json(file_path)
                
            if success:
                self.config = self.config_manager.get_config()
                self._load_config()
                messagebox.showinfo("成功", "配置已导入")
            else:
                messagebox.showerror("错误", "导入配置失败")
                
        except Exception as e:
            messagebox.showerror("错误", f"导入失败: {e}")
            
    def _export_config(self):
        """导出配置"""
        file_path = filedialog.asksaveasfilename(
            title="导出配置",
            defaultextension=".json",
            filetypes=[
                ("JSON文件", "*.json"),
                ("YAML文件", "*.yaml"),
                ("所有文件", "*.*")
            ]
        )
        
        if not file_path:
            return
            
        try:
            if file_path.endswith('.yaml') or file_path.endswith('.yml'):
                success = self.config_manager.export_to_yaml(file_path)
            else:
                success = self.config_manager.export_to_json(file_path)
                
            if success:
                messagebox.showinfo("成功", f"配置已导出到:\n{file_path}")
            else:
                messagebox.showerror("错误", "导出配置失败")
                
        except Exception as e:
            messagebox.showerror("错误", f"导出失败: {e}")
