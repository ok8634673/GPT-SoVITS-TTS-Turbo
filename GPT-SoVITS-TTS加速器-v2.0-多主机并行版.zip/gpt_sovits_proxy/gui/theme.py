"""
主题管理
"""
import customtkinter as ctk


class ThemeManager:
    """主题管理器"""
    
    # 颜色配置
    COLORS = {
        "dark": {
            "bg_primary": "#1a1a2e",
            "bg_secondary": "#16213e",
            "bg_tertiary": "#0f3460",
            "accent": "#e94560",
            "accent_hover": "#ff6b6b",
            "text_primary": "#ffffff",
            "text_secondary": "#a0a0a0",
            "success": "#4ade80",
            "warning": "#fbbf24",
            "error": "#f87171",
            "online": "#4ade80",
            "offline": "#f87171",
            "busy": "#fbbf24"
        },
        "light": {
            "bg_primary": "#f8fafc",
            "bg_secondary": "#f1f5f9",
            "bg_tertiary": "#e2e8f0",
            "accent": "#3b82f6",
            "accent_hover": "#2563eb",
            "text_primary": "#1e293b",
            "text_secondary": "#64748b",
            "success": "#22c55e",
            "warning": "#f59e0b",
            "error": "#ef4444",
            "online": "#22c55e",
            "offline": "#ef4444",
            "busy": "#f59e0b"
        }
    }
    
    @classmethod
    def apply_theme(cls, theme: str = "dark"):
        """应用主题"""
        ctk.set_appearance_mode(theme)
        ctk.set_default_color_theme("blue")
        
    @classmethod
    def get_color(cls, color_name: str, theme: str = "dark") -> str:
        """获取颜色"""
        return cls.COLORS.get(theme, cls.COLORS["dark"]).get(color_name, "#ffffff")
        
    @classmethod
    def get_status_color(cls, status: str, theme: str = "dark") -> str:
        """获取状态颜色"""
        colors = cls.COLORS.get(theme, cls.COLORS["dark"])
        return colors.get(status, colors["text_secondary"])


# 字体配置
class Fonts:
    """字体配置"""
    TITLE = ("Microsoft YaHei UI", 20, "bold")
    HEADER = ("Microsoft YaHei UI", 16, "bold")
    SUBHEADER = ("Microsoft YaHei UI", 14, "bold")
    BODY = ("Microsoft YaHei UI", 12)
    BODY_LARGE = ("Microsoft YaHei UI", 13)
    SMALL = ("Microsoft YaHei UI", 10)
    MONO = ("Consolas", 11)
