"""
FastAPI 应用主文件
"""
import asyncio
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import Response, JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from .models.server_config import TTSRequest, ProxyConfig, ServerConfig, LoadBalanceStrategy
from .core.load_balancer import LoadBalancer
from .core.audio_merger import AudioMerger
from .core.task_queue import TaskQueue
from .core.api_proxy import APIProxy
from .core.cluster_manager import ClusterManager
from .utils.config import ConfigManager
from .utils.logger import get_logger

logger = get_logger()

# 全局组件
config_manager: Optional[ConfigManager] = None
load_balancer: Optional[LoadBalancer] = None
audio_merger: Optional[AudioMerger] = None
task_queue: Optional[TaskQueue] = None
api_proxy: Optional[APIProxy] = None
cluster_manager: Optional[ClusterManager] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """应用生命周期管理"""
    global config_manager, load_balancer, audio_merger, task_queue, api_proxy, cluster_manager
    
    # 启动时初始化
    logger.info("正在初始化服务...")
    
    # 加载配置
    config_manager = ConfigManager()
    config = config_manager.load()
    
    # 初始化组件
    load_balancer = LoadBalancer(strategy=config.load_balance_strategy)
    
    # 添加服务器
    for server_config in config.servers:
        if server_config.enabled:
            load_balancer.add_server(server_config)
    
    # 启动时对所有服务器进行健康检查
    logger.info("正在进行服务器健康检查...")
    health_results = await load_balancer.health_check()
    online_count = sum(1 for success in health_results.values() if success)
    logger.info(f"健康检查完成，{online_count} 个服务器在线")
    
    audio_merger = AudioMerger()
    task_queue = TaskQueue(max_concurrent=10)
    
    api_proxy = APIProxy(
        load_balancer=load_balancer,
        task_queue=task_queue,
        audio_merger=audio_merger,
        request_timeout=config.request_timeout,
        max_retries=config.max_retries,
        retry_delay=config.retry_delay
    )
    
    # 启动任务队列
    await task_queue.start()
    
    # 初始化集群管理器
    cluster_manager = ClusterManager(config.cluster)
    await cluster_manager.start()
    
    logger.info(f"服务初始化完成，已加载 {len(config.servers)} 个服务器")
    
    yield
    
    # 关闭时清理
    logger.info("正在关闭服务...")
    await task_queue.stop()
    await cluster_manager.stop()
    logger.info("服务已关闭")


# 创建FastAPI应用
app = FastAPI(
    title="GPT-SoVITS Proxy",
    description="GPT-SoVITS 加速服务器 - API代理服务",
    version="1.0.0",
    lifespan=lifespan
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """根路径"""
    return {
        "name": "GPT-SoVITS Proxy",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    if not load_balancer:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    available = load_balancer.get_available_servers()
    return {
        "status": "healthy",
        "available_servers": len(available),
        "total_servers": len(load_balancer.servers)
    }


@app.post("/tts")
async def text_to_speech(request: TTSRequest):
    """
    TTS语音合成接口
    
    接收文本，分发到多个GPT-SoVITS服务器进行合成，
    然后合并音频片段返回完整音频
    """
    if not api_proxy:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    # 检查是否有可用服务器
    available = load_balancer.get_available_servers()
    if not available:
        raise HTTPException(status_code=503, detail="没有可用的TTS服务器")
    
    logger.info(f"收到TTS请求，文本长度: {len(request.text)}，可用服务器: {len(available)}")
    
    try:
        # 处理请求
        audio_data = await api_proxy.process_tts_request(request)
        
        if audio_data:
            return Response(
                content=audio_data,
                media_type="audio/wav",
                headers={
                    "Content-Disposition": "attachment; filename=output.wav"
                }
            )
        else:
            raise HTTPException(status_code=500, detail="音频生成失败")
            
    except Exception as e:
        logger.error(f"TTS处理失败: {e}")
        raise HTTPException(status_code=500, detail=f"处理失败: {str(e)}")


@app.get("/tts")
async def text_to_speech_get(
    text: str,
    text_lang: str = "auto",
    speed_factor: float = 1.0,
    temperature: float = 1.0,
    top_k: int = 5,
    top_p: float = 1.0,
    text_split_method: str = "cut4",
    batch_size: int = 1,
    ref_audio_path: Optional[str] = None,
    prompt_text: Optional[str] = None,
    prompt_lang: Optional[str] = None,
    server_id: Optional[str] = None
):
    """
    TTS语音合成接口 (GET方法)
    
    接收GET请求参数，转换为POST请求格式，
    然后分发到多个GPT-SoVITS服务器进行合成
    """
    if not api_proxy:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    # 检查是否有可用服务器
    available = load_balancer.get_available_servers()
    if not available:
        raise HTTPException(status_code=503, detail="没有可用的TTS服务器")
    
    logger.info(f"收到GET TTS请求，文本长度: {len(text)}，可用服务器: {len(available)}")
    
    try:
        # 构建TTS请求
        request = TTSRequest(
            text=text,
            text_lang=text_lang,
            speed_factor=speed_factor,
            temperature=temperature,
            top_k=top_k,
            top_p=top_p,
            text_split_method=text_split_method,
            batch_size=batch_size,
            ref_audio_path=ref_audio_path,
            prompt_text=prompt_text,
            prompt_lang=prompt_lang,
            server_id=server_id
        )
        
        # 处理请求
        audio_data = await api_proxy.process_tts_request(request)
        
        if audio_data:
            return Response(
                content=audio_data,
                media_type="audio/wav",
                headers={
                    "Content-Disposition": "attachment; filename=output.wav"
                }
            )
        else:
            raise HTTPException(status_code=500, detail="音频生成失败")
            
    except Exception as e:
        logger.error(f"TTS处理失败: {e}")
        raise HTTPException(status_code=500, detail=f"处理失败: {str(e)}")


@app.post("/tts/async")
async def text_to_speech_async(request: TTSRequest, background_tasks: BackgroundTasks):
    """
    异步TTS语音合成接口
    
    提交任务到队列，返回任务ID
    """
    if not api_proxy:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    task_id = await api_proxy.submit_tts_task(request)
    
    return {
        "task_id": task_id,
        "status": "pending",
        "message": "任务已提交"
    }


@app.get("/task/{task_id}")
async def get_task_status(task_id: str):
    """获取任务状态"""
    if not task_queue:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    task = task_queue.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    
    return {
        "task_id": task.id,
        "status": task.status.value,
        "progress": task.progress,
        "created_at": task.created_at,
        "completed_at": task.completed_at,
        "error": task.error_message
    }


@app.get("/tasks")
async def get_all_tasks():
    """获取所有任务"""
    if not task_queue:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    tasks = task_queue.get_all_tasks()
    return {
        "tasks": [
            {
                "task_id": t.id,
                "status": t.status.value,
                "progress": t.progress,
                "text_preview": t.request.text[:50] + "..." if len(t.request.text) > 50 else t.request.text
            }
            for t in tasks
        ]
    }


@app.get("/servers")
async def get_servers():
    """获取服务器列表"""
    if not load_balancer:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    return {
        "servers": [
            {
                "id": s.id,
                "name": s.name,
                "address": s.address,
                "port": s.port,
                "status": s.status.value,
                "enabled": s.enabled,
                "current_connections": s.current_connections,
                "total_requests": s.total_requests,
                "failed_requests": s.failed_requests
            }
            for s in load_balancer.servers
        ]
    }


@app.post("/servers/{server_id}/test")
async def test_server(server_id: str):
    """测试服务器连接"""
    if not api_proxy:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    server = load_balancer.get_server(server_id)
    if not server:
        raise HTTPException(status_code=404, detail="服务器不存在")
    
    result = await api_proxy.test_server(server)
    return result


@app.post("/servers/health-check")
async def health_check_all():
    """健康检查所有服务器"""
    if not api_proxy:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    results = await api_proxy.health_check_all()
    return results


@app.get("/stats")
async def get_stats():
    """获取统计信息"""
    if not task_queue or not load_balancer:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    task_stats = task_queue.get_stats()
    
    return {
        "tasks": task_stats,
        "servers": {
            "total": len(load_balancer.servers),
            "available": len(load_balancer.get_available_servers())
        }
    }


@app.get("/cluster/status")
async def get_cluster_status():
    """获取集群状态"""
    if not cluster_manager:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    return {
        "enabled": cluster_manager.config.enabled,
        "mode": cluster_manager.mode.value,
        "node_id": cluster_manager.node_id,
        "node_name": cluster_manager.node_name,
        "slaves": [
            {
                "id": s.node_id,
                "name": s.node_name,
                "address": s.address,
                "port": s.port,
                "status": s.status
            }
            for s in cluster_manager.get_slave_nodes()
        ] if cluster_manager.is_master() else []
    }


# 配置更新接口（供GUI调用）
@app.post("/admin/reload-config")
async def reload_config():
    """重新加载配置"""
    global config_manager, load_balancer
    
    if not config_manager or not load_balancer:
        raise HTTPException(status_code=503, detail="服务未初始化")
    
    try:
        config = config_manager.load()
        
        # 清空并重新加载服务器
        load_balancer.servers.clear()
        for server_config in config.servers:
            if server_config.enabled:
                load_balancer.add_server(server_config)
        
        # 重新加载后进行健康检查
        health_results = await load_balancer.health_check()
        online_count = sum(1 for success in health_results.values() if success)
        
        return {"success": True, "message": f"已加载 {len(load_balancer.servers)} 个服务器，{online_count} 个在线"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"重新加载失败: {str(e)}")


def create_app() -> FastAPI:
    """创建应用实例（供外部调用）"""
    return app
