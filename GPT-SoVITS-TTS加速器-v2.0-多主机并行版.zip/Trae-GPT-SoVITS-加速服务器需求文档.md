# GPT-SoVITS 加速服务器 - 需求文档

## 📋 项目概述

### 项目名称
**GPT-SoVITS 加速服务器**（简称：GPT-SoVITS-Proxy）

### 项目描述
一个基于 Python 的带 GUI 的 API 请求转发和负载均衡服务，用于加速 GPT-SoVITS 语音生成。通过将请求拆分并并发发送到多个 GPT-SoVITS 服务器，然后拼合音频片段，实现高并发、高可用的语音生成服务。

---

## 🎯 核心功能

### 1. API 请求转发
- 接收 GPT-SoVITS 风格的 API 请求
- 支持标准的 `/tts` 接口格式
- 请求参数完全兼容 GPT-SoVITS API

### 2. 多服务器负载均衡
- 支持配置多个 GPT-SoVITS 服务器节点
- 自动拆分请求到不同服务器
- 负载均衡算法（建议使用轮询或最少连接）
- 支持服务器健康检查和自动故障转移

### 3. 语音片段拼合
- 接收各服务器的音频片段
- 按原始顺序拼合音频数据
- 保持音频质量和完整性
- 支持多种音频格式（WAV）

### 4. GUI 管理界面
- **简洁大方的设计风格**
- **鼠标操作为主**，减少键盘输入
- 实时显示服务器状态
- 实时显示任务进度
- 支持配置数据的导出与导入

---

## 🏗️ 系统架构

### 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    GPT-SoVITS-Proxy (GUI)                    │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  API 请求接收层                                       │   │
│  │  - 接收 HTTP POST 请求                                │   │
│  │  - 参数解析和验证                                     │   │
│  │  - 请求路由                                           │   │
│  └─────────────────────────────────────────────────────┘   │
│                           ↓                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  任务调度层                                           │   │
│  │  - 请求拆分                                           │   │
│  │  - 负载均衡                                           │   │
│  │  - 任务队列管理                                       │   │
│  └─────────────────────────────────────────────────────┘   │
│                           ↓                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  并发执行层                                           │   │
│  │  - 多线程/多进程请求发送                              │   │
│  │  - 异步任务处理                                       │   │
│  └─────────────────────────────────────────────────────┘   │
│                           ↓                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  音频拼合层                                           │   │
│  │  - 接收各服务器响应                                   │   │
│  │  - 按序拼合音频                                       │   │
│  │  - 格式转换                                           │   │
│  └─────────────────────────────────────────────────────┘   │
│                           ↓                                 │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  响应返回层                                           │   │
│  │  - 构造标准响应                                       │   │
│  │  - 返回音频文件                                       │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─────────────────────────────────────────────────────────────┐
│                  GPT-SoVITS 服务器集群                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ 服务器 1     │  │ 服务器 2     │  │ 服务器 3     │      │
│  │ 192.168.1.1  │  │ 192.168.1.2  │  │ 192.168.1.3  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
│  ...                                                         │
└─────────────────────────────────────────────────────────────┘
```

### 技术栈建议

**后端：**
- **Python 3.10+** - 主开发语言
- **FastAPI** - 高性能异步 Web 框架
- **Pydantic** - 数据验证和序列化
- **asyncio** - 异步任务处理
- **requests** - HTTP 请求库
- **wave** / **numpy** - 音频处理

**GUI 框架（三选一）：**
1. **PyQt6 / PySide6** - 专业级 GUI，功能强大
2. **CustomTkinter** - 现代化 Tkinter，简洁美观
3. **Dear PyGui** - 现代 ImGui 风格，实时性好

**配置管理：**
- **JSON** - 配置文件格式
- **YAML** - 可读性更好的配置格式

---

## 📡 API 接口规范

### 接口定义

#### 1. 主接口：语音生成

**端点：** `POST /tts`

**功能：** 接收语音生成请求，转发到多个服务器并返回完整音频

**请求格式：** JSON

**请求参数：**

```json
{
  "ref_audio_path": "string (必需)",
  "prompt_text": "string (必需)",
  "prompt_lang": "string (必需)",
  "text": "string (必需)",
  "text_lang": "string (可选，默认: auto)",
  "output_dir": "string (可选，默认: tmp/)",
  "top_k": "integer (可选，默认: 5)",
  "top_p": "float (可选，默认: 1)",
  "temperature": "float (可选，默认: 1)",
  "text_split_method": "string (可选，默认: cut4)",
  "batch_size": "integer (可选，默认: 1)",
  "speed_factor": "float (可选，默认: 1.0)"
}
```

**响应格式：** WAV 音频文件（二进制数据）

**错误响应：**

```json
{
  "error": "string (错误描述)",
  "code": "string (错误码)"
}
```

### 接口实现示例

#### 请求流程

1. **接收请求** - 解析 JSON 参数
2. **验证参数** - 检查必需字段
3. **文本拆分** - 根据配置拆分文本为多个片段
4. **路由请求** - 将片段分配到不同服务器
5. **并发请求** - 发送请求到多个服务器
6. **等待响应** - 收集所有服务器的响应
7. **拼合音频** - 按顺序拼合音频片段
8. **返回结果** - 返回完整的 WAV 文件

#### 响应示例

**成功响应：**
```
Content-Type: audio/wav
Content-Disposition: attachment; filename="output.wav"
```
（二进制 WAV 数据）

**错误响应：**
```json
{
  "error": "服务器 1 连接失败",
  "code": "SERVER_ERROR",
  "server_index": 0
}
```

---

## 🎨 GUI 设计要求

### 整体风格

- **简洁大方** - 清晰的布局，不拥挤
- **现代设计** - 使用现代 UI 框架，支持深色/浅色主题
- **响应式布局** - 适应不同屏幕尺寸
- **鼠标操作为主** - 减少键盘输入，提升用户体验

### 主要界面

#### 1. 主界面

**布局结构：**
```
┌─────────────────────────────────────────────────────────┐
│  GPT-SoVITS 加速服务器 v1.0                              │
├──────────────┬──────────────────────────────────────────┤
│              │  ┌────────────────────────────────────┐  │
│  服务器列表  │  │  任务列表                            │  │
│              │  │  - 任务 1: 正在处理                 │  │
│  [添加服务器]│  │  - 任务 2: 已完成                   │  │
│              │  │  - 任务 3: 失败                    │  │
│  - 192.168.1.1│  └────────────────────────────────────┘  │
│    状态: ●在线│                                           │
│  - 192.168.1.2│  ┌────────────────────────────────────┐  │
│    状态: ●在线│  │  服务器状态                          │  │
│  - 192.168.1.3│  │  服务器 1: 3/10 请求               │  │
│    状态: ●在线│  │  服务器 2: 2/10 请求               │  │
│              │  │  服务器 3: 5/10 请求               │  │
│  [导出配置]  │  └────────────────────────────────────┘  │
│  [导入配置]  │                                           │
│  [启动服务]  │  ┌────────────────────────────────────┐  │
│  [停止服务]  │  │  快速操作                            │  │
│              │  │  [测试连接] [查看日志] [退出]       │  │
│  [设置]      │  └────────────────────────────────────┘  │
└──────────────┴──────────────────────────────────────────┘
```

#### 2. 添加/编辑服务器对话框

**表单字段：**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 服务器名称 | 文本输入 | 是 | 服务器别名 |
| 服务器地址 | IP地址 | 是 | 例如：192.168.1.1 |
| API 端口 | 数字 | 是 | 例如：9880 |
| 参考音频路径 | 文本输入 | 是 | 参考音频文件路径 |
| 参考音频文本 | 文本输入 | 是 | 对应的文本内容 |
| 参考音频语言 | 下拉选择 | 是 | zh/en/ja |
| 负载均衡策略 | 下拉选择 | 是 | round-robin/least-connections |
| 是否启用 | 开关 | 是 | 启用/禁用服务器 |

#### 3. 配置管理界面

**功能：**
- 导出配置到 JSON/YAML 文件
- 从文件导入配置
- 预览配置内容
- 验证配置格式

#### 4. 日志查看界面

**功能：**
- 实时显示系统日志
- 日志级别过滤（INFO/WARNING/ERROR）
- 日志搜索功能
- 日志导出功能

### 5. 中文路径处理

**功能：**
- 支持中文路径和文件名
- 自动处理编码转换
- 提供配置选项控制编码方式
- 防止中文路径导致的朗读失败

### 交互设计

#### 鼠标操作

1. **双击服务器项** - 编辑服务器配置
2. **右键服务器项** - 查看详情/删除/测试连接
3. **拖拽排序** - 调整服务器顺序
4. **点击按钮** - 执行主要操作
5. **双击任务项** - 查看任务详情

#### 快捷操作

- **Ctrl+S** - 保存配置
- **Ctrl+O** - 导入配置
- **F5** - 刷新状态
- **Esc** - 关闭对话框

---

## ⚙️ 配置文件格式

### 配置文件结构

#### JSON 格式示例

```json
{
  "version": "1.0",
  "server_name": "GPT-SoVITS-Proxy",
  "server_port": 9889,
  "host": "0.0.0.0",
  "servers": [
    {
      "id": 1,
      "name": "服务器 1",
      "address": "192.168.1.1",
      "port": 9880,
      "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
      "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
      "prompt_lang": "zh",
      "enabled": true,
      "load_balance": "round-robin",
      "max_connections": 10
    },
    {
      "id": 2,
      "name": "服务器 2",
      "address": "192.168.1.2",
      "port": 9880,
      "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/xxx.wav",
      "prompt_text": "参考音频文本内容",
      "prompt_lang": "zh",
      "enabled": true,
      "load_balance": "round-robin",
      "max_connections": 10
    }
  ],
  "default_config": {
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  },
  "ui_settings": {
    "theme": "dark",
    "window_width": 1200,
    "window_height": 800,
    "auto_save": true,
    "auto_save_interval": 60,
    "cache_folder": "cache",
    "auto_start_service": false,
    "auto_start_on_boot": false
  },
  "encoding_settings": {
    "enable_utf8_encoding": true,
    "force_utf8_for_paths": true,
    "path_encoding": "utf-8",
    "response_encoding": "utf-8"
  }
}
```

#### YAML 格式示例

```yaml
version: "1.0"
server_name: "GPT-SoVITS-Proxy"
server_port: 9889
host: "0.0.0.0"

servers:
  - id: 1
    name: "服务器 1"
    address: "192.168.1.1"
    port: 9880
    ref_audio_path: "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav"
    prompt_text: "买东西那天也有一个人帮了开了款式，那个人好像叫"
    prompt_lang: "zh"
    enabled: true
    load_balance: "round-robin"
    max_connections: 10

  - id: 2
    name: "服务器 2"
    address: "192.168.1.2"
    port: 9880
    ref_audio_path: "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/xxx.wav"
    prompt_text: "参考音频文本内容"
    prompt_lang: "zh"
    enabled: true
    load_balance: "round-robin"
    max_connections: 10

default_config:
  text_lang: "auto"
  top_k: 5
  top_p: 1
  temperature: 1
  text_split_method: "cut4"
  batch_size: 1
  speed_factor: 1.0

ui_settings:
  theme: "dark"
  window_width: 1200
  window_height: 800
  auto_save: true
  auto_save_interval: 60
  cache_folder: "cache"
  auto_start_service: false
  auto_start_on_boot: false

encoding_settings:
  enable_utf8_encoding: true
  force_utf8_for_paths: true
  path_encoding: "utf-8"
  response_encoding: "utf-8"
```

### 配置文件路径

- **默认路径：** `config.json`（同目录下）
- **自定义路径：** 用户可指定

---

## 📊 负载均衡策略

### 1. 轮询（Round-Robin）

**算法：**
```
请求 1 → 服务器 1
请求 2 → 服务器 2
请求 3 → 服务器 3
请求 4 → 服务器 1
...
```

**适用场景：** 服务器性能相近时

### 2. 最少连接（Least Connections）

**算法：**
```
请求 1 → 服务器 1（当前连接数: 0）
请求 2 → 服务器 2（当前连接数: 0）
请求 3 → 服务器 1（当前连接数: 1）
请求 4 → 服务器 3（当前连接数: 0）
请求 5 → 服务器 2（当前连接数: 1）
请求 6 → 服务器 1（当前连接数: 2）
...
```

**适用场景：** 服务器性能差异较大时

### 3. 加权轮询（Weighted Round-Robin）

**算法：** 根据服务器权重分配请求

**适用场景：** 不同服务器性能差异较大时

---

## 🔄 工作流程

### 完整请求流程

```
1. 客户端发送请求
   ↓
2. Proxy 接收请求
   ↓
3. 验证参数
   ↓
4. 处理中文路径（编码转换）
   ↓
5. 拆分文本（如果需要）
   ↓
6. 分配服务器
   ↓
7. 发送请求到各服务器（并发，包含编码处理）
   ↓
8. 等待所有响应
   ↓
9. 拼合音频
   ↓
10. 返回完整音频给客户端
```

### 文本拆分策略

**策略 1：按长度拆分**
- 根据最大文本长度限制拆分
- 保持语义完整性

**策略 2：按句子拆分**
- 按标点符号拆分
- 每个片段包含完整句子

**策略 3：按段落拆分**
- 按段落边界拆分
- 适合长文本

**默认：** 使用 `cut4` 方法（与 GPT-SoVITS 保持一致）

---

## 🛠️ 开发要求

### 代码结构

```
GPT-SoVITS-Proxy/
├── main.py                    # 主入口文件
├── app.py                     # FastAPI 应用
├── gui/                       # GUI 模块
│   ├── main_window.py         # 主窗口
│   ├── server_dialog.py       # 服务器配置对话框
│   ├── config_dialog.py       # 配置管理对话框
│   ├── log_window.py          # 日志查看窗口
│   └── theme.py               # 主题管理
├── core/                      # 核心功能模块
│   ├── api_proxy.py           # API 代理逻辑
│   ├── load_balancer.py       # 负载均衡
│   ├── audio_merger.py        # 音频拼合
│   └── task_queue.py          # 任务队列
├── utils/                     # 工具函数
│   ├── config.py              # 配置管理
│   ├── logger.py              # 日志管理
│   └── audio_utils.py         # 音频处理工具
├── models/                    # 数据模型
│   └── server_config.py       # 服务器配置模型
├── config.json                # 默认配置文件
├── requirements.txt           # 依赖列表
└── README.md                  # 项目说明
```

### 依赖包（requirements.txt）

```
fastapi>=0.104.0
uvicorn>=0.24.0
pydantic>=2.0.0
requests>=2.31.0
numpy>=1.24.0
pyaudio>=0.2.13
pywave>=0.1.2
pyyaml>=6.0
customtkinter>=5.2.0
pygame>=2.5.0
winshell>=0.6
pywin32>=306
```

### 代码规范

- **Python 3.10+** - 使用现代 Python 特性
- **类型注解** - 所有函数和变量添加类型注解
- **Docstrings** - 每个函数添加文档字符串
- **错误处理** - 完善的错误处理和日志记录
- **异步编程** - 使用 asyncio 提升性能
- **代码注释** - 关键逻辑添加注释

---

## 🧪 测试要求

### 单元测试

- 服务器配置管理
- 负载均衡算法
- 音频拼合功能
- API 请求转发

### 集成测试

- 端到端请求流程
- 多服务器并发处理
- 故障转移机制
- 配置导入导出

### 性能测试

- 并发请求处理能力
- 音频生成延迟
- 服务器负载均衡效果

---

## 📝 使用说明

### 安装步骤

1. **克隆/下载项目**
2. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```
3. **配置服务器**
   - 启动程序
   - 添加 GPT-SoVITS 服务器
   - 配置参考音频
4. **启动服务**
   - 点击"启动服务"按钮
   - 访问 API 端点进行测试

## 🀄 中文路径处理解决方案

### 问题描述

在使用 GPT-SoVITS 时，参考音频路径或文件名包含中文字符可能会导致以下问题：
- API 请求失败，返回 404 或 500 错误
- 服务器无法找到参考音频文件
- 音频生成失败，提示"文件不存在"

### 根本原因

1. **编码不一致**：不同系统和库使用的字符编码不同
2. **路径转义**：JSON 序列化/反序列化过程中对中文路径的处理不当
3. **HTTP 传输**：HTTP 请求中对中文字符的编码处理

### 解决方案

#### 1. API 请求编码处理

**实现方式：**

```python
# 在 api_proxy.py 中使用手动序列化 JSON 并指定 UTF-8 编码
import json

async def forward_request(self, server, payload):
    # 手动序列化 JSON 以确保 UTF-8 编码
    json_payload = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    
    async with session.post(
        server.get_url(),
        data=json_payload,
        timeout=aiohttp.ClientTimeout(total=self.request_timeout),
        headers={"Content-Type": "application/json; charset=utf-8"}
    ) as response:
        # 处理响应
        pass
```

#### 2. 路径处理和规范化

**实现方式：**

```python
# 在 utils/path_utils.py 中添加路径处理函数
import os
import urllib.parse

def normalize_path(path):
    """规范化路径，处理中文路径"""
    # 确保路径使用正确的分隔符
    normalized = os.path.normpath(path)
    # 处理路径中的中文字符
    try:
        # 尝试使用 UTF-8 编码
        encoded_path = normalized.encode('utf-8').decode('utf-8')
        return encoded_path
    except Exception:
        return normalized

def url_encode_path(path):
    """URL 编码路径，确保中文字符正确传输"""
    # 对路径进行 URL 编码
    return urllib.parse.quote(path, safe='/\\:')
```

#### 3. 配置文件编码处理

**实现方式：**

```python
# 在 utils/config.py 中处理配置文件编码
import json

def load_config(config_path):
    """加载配置文件，确保 UTF-8 编码"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_config(config_path, config):
    """保存配置文件，使用 UTF-8 编码"""
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
```

#### 4. 服务器健康检查中的路径验证

**实现方式：**

```python
# 在 core/server_manager.py 中添加路径验证
async def check_server_health(self, server):
    """检查服务器健康状态，包括路径验证"""
    try:
        # 构建测试请求
        test_payload = {
            "ref_audio_path": server.ref_audio_path,
            "prompt_text": server.prompt_text,
            "prompt_lang": server.prompt_lang,
            "text": "测试音频",
            "text_lang": "zh"
        }
        
        # 使用 UTF-8 编码发送请求
        import json
        json_payload = json.dumps(test_payload, ensure_ascii=False).encode('utf-8')
        
        # 发送请求并验证
        # ...
        
    except Exception as e:
        # 处理错误
        pass
```

### 最佳实践

1. **使用正斜杠**：在配置文件中使用正斜杠（/）作为路径分隔符
2. **避免特殊字符**：路径中避免使用特殊字符，如空格、括号等
3. **使用绝对路径**：尽量使用绝对路径而非相对路径
4. **编码一致性**：确保所有组件使用相同的编码（UTF-8）
5. **路径验证**：在配置时验证路径的有效性

### 故障排除

**常见问题及解决方案：**

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 404 错误 | 路径不存在 | 检查路径是否正确，使用绝对路径 |
| 500 错误 | 编码问题 | 确保使用 UTF-8 编码发送请求 |
| 路径乱码 | 编码不一致 | 手动指定 UTF-8 编码 |
| 文件未找到 | 路径格式错误 | 使用正斜杠，避免反斜杠转义 |

### 实现效果

通过以上解决方案，系统能够：
- 正确处理包含中文字符的参考音频路径
- 确保 API 请求中的中文路径正确传输
- 避免因编码问题导致的音频生成失败
- 提供一致的跨平台路径处理体验

### API 使用示例

#### Python 示例

```python
import requests

# 请求示例
url = "http://localhost:9889/tts"
payload = {
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
}

# 发送请求
response = requests.post(url, json=payload)

# 保存音频
if response.status_code == 200:
    with open("output.wav", "wb") as f:
        f.write(response.content)
    print("✅ 音频生成成功！")
else:
    print(f"❌ 生成失败: {response.status_code}")
```

#### cURL 示例

```bash
curl -X POST "http://localhost:9889/tts" \
  -H "Content-Type: application/json" \
  -d '{
    "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
    "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
    "prompt_lang": "zh",
    "text": "你好，我是可莉！很高兴为你服务。",
    "text_lang": "auto",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "text_split_method": "cut4",
    "batch_size": 1,
    "speed_factor": 1.0
  }' --output output.wav
```

---

## 🎨 UI 设计规范

### 颜色方案

**深色主题：**
- 背景：#1E1E1E
- 前景：#E0E0E0
- 主色调：#4A90E2（蓝色）
- 成功色：#4CAF50（绿色）
- 错误色：#F44336（红色）
- 警告色：#FF9800（橙色）

**浅色主题：**
- 背景：#FFFFFF
- 前景：#333333
- 主色调：#2196F3（蓝色）
- 成功色：#4CAF50（绿色）
- 错误色：#F44336（红色）
- 警告色：#FF9800（橙色）

### 字体规范

- **字体：** Microsoft YaHei / PingFang SC
- **大小：**
  - 标题：14pt
  - 正文：12pt
  - 小字：10pt

### 间距规范

- **窗口内边距：** 16px
- **组件间距：** 8px
- **元素间距：** 4px

---

## 🪟 Windows 10/11 部署指南

### 系统要求

#### Windows 10
- **版本：** Windows 10 1803 或更高版本（建议 21H2 或更高）
- **处理器：** 1 GHz 或更快的处理器（多核处理器推荐）
- **内存：** 最低 4GB RAM（推荐 8GB 或更高）
- **硬盘：** 至少 500MB 可用空间
- **网络：** 有线或 Wi-Fi 连接

#### Windows 11
- **版本：** Windows 11 21H2 或更高版本
- **处理器：** 1 GHz 或更快的双核处理器
- **内存：** 最低 4GB RAM（推荐 8GB 或更高）
- **硬盘：** 至少 500MB 可用空间
- **网络：** 有线或 Wi-Fi 连接

### 前置准备

#### 1. 安装 Python 3.10+

**下载地址：** https://www.python.org/downloads/

**安装步骤：**
1. 下载 Python 3.10.x 或更高版本（推荐 3.10.11）
2. 运行安装程序
3. **重要：** 勾选 "Add Python to PATH"（将 Python 添加到系统路径）
4. 点击 "Install Now" 或 "Customize installation"
5. 在自定义安装中，确保勾选 "pip" 和 "tcl/tk and IDLE"
6. 完成安装后，验证安装：
   ```cmd
   python --version
   pip --version
   ```

**验证安装：**
```cmd
python -c "import sys; print(f'Python {sys.version}')"
```

#### 2. 安装 Visual C++ Redistributable

**原因：** 部分 Python 包依赖 Visual C++ 运行时

**下载地址：**
- [Microsoft Visual C++ 2015-2022 Redistributable (x64)](https://aka.ms/vs/17/release/vc_redist.x64.exe)
- [Microsoft Visual C++ 2015-2022 Redistributable (x86)](https://aka.ms/vs/17/release/vc_redist.x86.exe)

**安装步骤：**
1. 下载上述两个文件（x64 和 x86）
2. 依次运行安装程序
3. 选择 "Install" 或 "Modify"
4. 完成安装

#### 3. 安装 FFmpeg（用于音频处理）

**下载地址：** https://www.gyan.dev/ffmpeg/builds/

**推荐版本：** ffmpeg-git-full.7z

**安装步骤：**
1. 下载 FFmpeg 7z 压缩包
2. 解压到 `C:\ffmpeg`
3. 添加 FFmpeg 到系统 PATH：
   - 右键 "此电脑" → "属性" → "高级系统设置"
   - 点击 "环境变量"
   - 在 "系统变量" 中找到 "Path"，点击 "编辑"
   - 添加 `C:\ffmpeg\bin`（如果需要 32 位支持，也添加 `C:\ffmpeg\bin\32`）
4. 验证安装：
   ```cmd
   ffmpeg -version
   ```

#### 4. 验证音频库依赖

**安装 PyAudio：**
```cmd
pip install pyaudio
```

如果安装失败，使用以下方法：

**方法一：使用预编译的 wheel**
```cmd
# 下载对应的 wheel 文件
# 访问：https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
# 根据你的 Python 版本和系统架构选择对应的 wheel

# 示例（Python 3.10, 64位）：
pip install PyAudio-0.2.13-cp310-cp310-win_amd64.whl
```

**方法二：使用 conda（如果安装了 Anaconda/Miniconda）**
```cmd
conda install -c conda-forge pyaudio
```

#### 5. 验证其他依赖

**安装所有依赖：**
```cmd
cd GPT-SoVITS-TTS加速器
pip install -r requirements.txt
```

**验证安装：**
```cmd
python -c "import fastapi; import uvicorn; import requests; import numpy; import wave; import yaml; import customtkinter; print('所有依赖安装成功！')"
```

### 部署步骤

#### 步骤 1：解压项目文件

1. 将项目文件夹解压到目标位置，例如：
   - `C:\Users\用户名\Documents\GPT-SoVITS-TTS加速器`
   - `D:\Projects\GPT-SoVITS-TTS加速器`

2. **重要：** 路径中避免使用中文和空格
   - ✅ 推荐：`C:\Projects\GPT-SoVITS-TTS加速器`
   - ❌ 不推荐：`D:\我的项目\GPT-SoVITS 加速器`

#### 步骤 2：创建配置文件

1. 复制 `config.json.example`（如果存在）或创建新的配置文件：
   ```cmd
   copy config.json.example config.json
   ```

2. 编辑 `config.json`，配置 GPT-SoVITS 服务器信息：
   ```json
   {
     "version": "1.0",
     "server_name": "GPT-SoVITS-Proxy",
     "server_port": 9889,
     "host": "0.0.0.0",
     "servers": [
       {
         "id": 1,
         "name": "服务器 1",
         "address": "192.168.1.1",
         "port": 9880,
         "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
         "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
         "prompt_lang": "zh",
         "enabled": true,
         "load_balance": "round-robin",
         "max_connections": 10
       }
     ],
     "default_config": {
       "text_lang": "auto",
       "top_k": 5,
       "top_p": 1,
       "temperature": 1,
       "text_split_method": "cut4",
       "batch_size": 1,
       "speed_factor": 1.0
     },
     "ui_settings": {
       "theme": "dark",
       "window_width": 1200,
       "window_height": 800,
       "auto_save": true,
       "auto_save_interval": 60
     }
   }
   ```

#### 步骤 3：启动程序

**方法一：使用命令行启动**
```cmd
cd GPT-SoVITS-TTS加速器
python main.py
```

**方法二：创建快捷方式**
1. 右键点击 `main.py` → "创建快捷方式"
2. 右键点击快捷方式 → "属性"
3. 在 "目标" 中添加 `--config config.json`（如果使用自定义配置）
4. 点击 "确定"

**方法三：创建批处理文件**
1. 创建新文件 `start.bat`：
   ```batch
   @echo off
   cd /d "%~dp0"
   python main.py --config config.json
   pause
   ```
2. 双击 `start.bat` 启动程序

#### 步骤 4：首次运行配置

1. 程序启动后，GUI 界面会自动显示
2. 点击 **"添加服务器"** 按钮
3. 填写服务器信息：
   - 服务器名称：例如 "我的可莉服务器"
   - 服务器地址：例如 "192.168.1.1"
   - API 端口：9880
   - 参考音频路径：`F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav`
   - 参考音频文本：`买东西那天也有一个人帮了开了款式，那个人好像叫`
   - 参考音频语言：选择 "zh"
   - 负载均衡策略：选择 "round-robin"
   - 是否启用：勾选
4. 点击 **"测试连接"** 验证服务器是否可访问
5. 点击 **"保存"** 保存配置
6. 点击 **"启动服务"** 启动 API 服务器

#### 步骤 5：验证部署

1. 访问 `http://localhost:9889/docs` 查看 API 文档（FastAPI 自动生成）
2. 使用 API 测试工具（如 Postman）发送测试请求：
   ```json
   {
     "ref_audio_path": "F:/GPT-SoVITS/GPT-SoVITS-v4-20250422fix/audio/klee-xxx.wav",
     "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
     "prompt_lang": "zh",
     "text": "你好，我是可莉！很高兴为你服务。",
     "text_lang": "auto",
     "top_k": 5,
     "top_p": 1,
     "temperature": 1,
     "text_split_method": "cut4",
     "batch_size": 1,
     "speed_factor": 1.0
   }
   ```
3. 下载生成的 `output.wav` 文件，验证音频质量

### Windows 特性优化

#### 1. 防火墙设置

**添加防火墙规则：**

**方法一：使用图形界面**
1. 打开 Windows Defender 防火墙
2. 点击 "高级设置"
3. 点击 "入站规则" → "新建规则"
4. 选择 "端口" → "TCP" → 特定本地端口：9889
5. 选择 "允许连接"
6. 选择所有配置文件（域、专用、公用）
7. 输入名称：GPT-SoVITS-Proxy
8. 完成

**方法二：使用命令行**
```cmd
netsh advfirewall firewall add rule name="GPT-SoVITS-Proxy" dir=in action=allow protocol=TCP localport=9889
```

#### 2. 设置开机自启动

**方法一：使用任务计划程序**
1. 按 `Win + R`，输入 `taskschd.msc`，回车
2. 右侧点击 "创建基本任务"
3. 名称：GPT-SoVITS-Proxy
4. 触发器：计算机启动时
5. 操作：启动程序
   - 程序：`C:\Python310\python.exe`
   - 参数：`C:\Projects\GPT-SoVITS-TTS加速器\main.py`
   - 起始于：`C:\Projects\GPT-SoVITS-TTS加速器`
6. 完成

**方法二：使用注册表**
1. 按 `Win + R`，输入 `regedit`，回车
2. 导航到：
   ```
   HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run
   ```
3. 右键点击右侧空白处 → "新建" → "字符串值"
4. 名称：`GPT-SoVITS-Proxy`
5. 数值数据：`C:\Python310\python.exe "C:\Projects\GPT-SoVITS-TTS加速器\main.py"`

#### 3. 设置高优先级（可选）

**使用任务计划程序设置高优先级：**
1. 在任务计划程序中找到刚创建的任务
2. 右键点击 → "属性"
3. 切换到 "条件" 选项卡
4. 勾选 "只有在计算机使用交流电源时才启动此任务"（可选）
5. 切换到 "设置" 选项卡
6. 勾选 "如果任务失败，按以下频率重新启动"
7. 重新启动间隔：1 分钟
8. 最大重启次数：3 次

#### 4. 隐藏控制台窗口（可选）

**创建批处理文件：**
```batch
@echo off
start /B python main.py --config config.json >nul 2>&1
exit
```

**注意：** 隐藏控制台窗口后无法直接查看日志，建议保留日志文件输出到文件中。

#### 5. 日志文件配置

在代码中添加日志文件输出：
```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('gpt_sovits_proxy.log'),
        logging.StreamHandler()
    ]
)
```

### 常见问题解决

#### 问题 1：Python 无法添加到 PATH

**解决方案：**
1. 重新运行 Python 安装程序
2. 在 "Advanced Options" 中勾选 "Add Python to PATH"
3. 点击 "Modify"
4. 完成后重启命令行

#### 问题 2：PyAudio 安装失败

**解决方案：**
```cmd
# 1. 下载对应的 wheel 文件
# 访问：https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio

# 2. 使用 pip 安装 wheel 文件
pip install PyAudio-0.2.13-cp310-cp310-win_amd64.whl

# 3. 如果仍然失败，尝试使用 conda
conda install -c conda-forge pyaudio
```

#### 问题 3：端口被占用

**错误信息：**
```
Address already in use: ('127.0.0.1', 9889)
```

**解决方案：**
1. 查找占用端口的进程：
   ```cmd
   netstat -ano | findstr :9889
   ```
2. 记录 PID，然后终止进程：
   ```cmd
   taskkill /PID <PID> /F
   ```
3. 修改配置文件中的端口号

#### 问题 4：防火墙阻止连接

**解决方案：**
参考上文"防火墙设置"章节，添加入站规则

#### 问题 5：中文路径或文件名问题

**解决方案：**
- **避免**使用中文路径和文件名
- 如果必须使用中文，在代码中添加路径处理：
  ```python
  import os
  path = os.path.normpath("你的中文路径")
  ```

#### 问题 6：GUI 无法显示

**解决方案：**
1. 检查是否安装了所有依赖：
   ```cmd
   pip install customtkinter
   ```
2. 检查显示设置：
   ```cmd
   python -c "import customtkinter; print(customtkinter.__version__)"
   ```

#### 问题 7：音频处理库错误

**错误信息：**
```
ImportError: DLL load failed
```

**解决方案：**
1. 安装 Visual C++ Redistributable
2. 重启计算机
3. 重新安装 PyAudio：
   ```cmd
   pip uninstall pyaudio
   pip install pyaudio
   ```

### 性能优化建议（Windows）

#### 1. 使用 SSD
- 将项目文件夹放在 SSD 上，提升读取速度

#### 2. 禁用不必要的启动项
- 打开任务管理器 → 启动选项卡 → 禁用不需要的程序

#### 3. 调整电源计划
- 设置为 "高性能" 模式

#### 4. 网络优化
- 使用有线连接替代 Wi-Fi
- 禁用 IPv6（如果不需要）

#### 5. 环境变量优化
- 将 Python 和 pip 的 Scripts 目录添加到 PATH
- 添加 `TMP` 和 `TEMP` 环境变量指向 SSD

### 卸载步骤

1. 停止并关闭程序
2. 删除项目文件夹
3. 删除配置文件（可选）
4. 卸载 Python（如果不再需要）
5. 卸载 Visual C++ Redistributable（如果不再需要）

---

## 🚀 部署说明

### 本地部署（Windows 10/11）

1. **安装依赖**
   ```cmd
   pip install -r requirements.txt
   ```

2. **配置服务器**
   - 运行程序
   - 添加 GPT-SoVITS 服务器
   - 配置参考音频路径

3. **启动服务**
   - 点击"启动服务"按钮
   - 访问 `http://localhost:9889`

### Docker 部署（可选）

```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

---

## 📈 性能优化

### 优化建议

1. **异步处理** - 使用 asyncio 提升并发性能
2. **连接池** - 复用 HTTP 连接
3. **缓存** - 缓存常用配置
4. **批处理** - 批量处理请求
5. **负载均衡** - 合理分配请求

### 性能指标

- **并发请求：** 支持 100+ 并发请求
- **响应延迟：** < 5秒（单个请求）
- **吞吐量：** > 100 请求/秒
- **音频质量：** 保持原始音频质量

---

## 🔒 安全性

### 安全措施

1. **输入验证** - 验证所有输入参数
2. **错误处理** - 不暴露敏感信息
3. **日志记录** - 记录所有操作
4. **配置加密** - 敏感信息加密存储（可选）

---

## 📚 参考资料

- **GPT-SoVITS API 文档：** `/home/terrence/Desktop/openclaw/GPT-SoVITS-API文档.md`
- **自我介绍：** `/home/terrence/Desktop/openclaw/自我介绍.md`
- **长期记忆：** `/home/terrence/.openclaw/workspace/MEMORY.md`

---

## ✅ 验收标准

### 功能验收

- [ ] API 接口正常工作
- [ ] 支持多个服务器配置
- [ ] 负载均衡正常
- [ ] 音频拼合正确
- [ ] GUI 界面简洁大方
- [ ] 鼠标操作流畅
- [ ] 配置可导出/导入
- [ ] 日志功能正常

### 性能验收

- [ ] 并发请求处理正常
- [ ] 响应延迟在可接受范围
- [ ] 服务器负载均衡合理

### 代码质量验收

- [ ] 代码结构清晰
- [ ] 类型注解完整
- [ ] 文档注释充分
- [ ] 错误处理完善

---

## 📞 联系方式

如有问题或需要进一步说明，请参考：
- GPT-SoVITS API 详细文档
- 项目代码注释
- 日志输出信息

---

**文档版本：** v1.1
**创建日期：** 2026-03-09
**更新日期：** 2026-03-09
**更新内容：** 添加 Windows 10/11 详细部署指南
**维护者：** 超级ロリ控
**目标工具：** Trae AI 编程助手
