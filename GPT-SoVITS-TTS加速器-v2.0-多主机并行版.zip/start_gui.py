import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    """启动GUI"""
    try:
        from gpt_sovits_proxy.gui import MainWindow
        
        # 创建主窗口
        window = MainWindow()
        
        # 运行应用
        window.run()
        
    except Exception as e:
        print(f"启动失败: {e}")
        import traceback
        traceback.print_exc()
        input("按回车键退出...")

if __name__ == "__main__":
    main()