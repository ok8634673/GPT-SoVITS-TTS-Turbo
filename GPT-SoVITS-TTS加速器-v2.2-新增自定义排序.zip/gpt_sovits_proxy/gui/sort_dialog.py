"""
排序对话框
"""
import customtkinter as ctk
from typing import Callable

from .theme import Fonts
from ..models.server_config import ServerConfig


class SortDialog(ctk.CTkToplevel):
    """服务器排序对话框"""
    
    def __init__(self, parent, servers: list[ServerConfig], callback: Callable):
        super().__init__(parent)
        
        self.servers = servers.copy()
        self.callback = callback
        self.server_frames = []
        
        self.title("服务器排序")
        self.geometry("500x450")
        self.resizable(False, False)
        
        self._create_ui()
        
        self.transient(parent)
        self.grab_set()
        
    def _create_ui(self):
        """创建UI"""
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        header = ctk.CTkFrame(self)
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        
        ctk.CTkLabel(
            header, 
            text="拖动或使用上下按钮调整服务器顺序", 
            font=Fonts.BODY
        ).pack(pady=5)
        
        self.server_list = ctk.CTkScrollableFrame(self)
        self.server_list.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        
        footer = ctk.CTkFrame(self)
        footer.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
        
        ctk.CTkButton(
            footer, 
            text="完成", 
            width=100,
            command=self._on_complete
        ).pack(side="right", padx=5)
        
        ctk.CTkButton(
            footer, 
            text="取消", 
            width=100,
            fg_color="gray",
            hover_color="darkgray",
            command=self.destroy
        ).pack(side="right", padx=5)
        
        self._update_list()
        
    def _update_list(self):
        """更新服务器列表"""
        for widget in self.server_list.winfo_children():
            widget.destroy()
            
        self.server_frames = []
        
        for i, server in enumerate(self.servers):
            frame = ctk.CTkFrame(self.server_list)
            frame.pack(fill="x", padx=5, pady=3)
            
            frame.grid_columnconfigure(1, weight=1)
            
            btn_frame = ctk.CTkFrame(frame, fg_color="transparent")
            btn_frame.grid(row=0, column=0, padx=5)
            
            up_btn = ctk.CTkButton(
                btn_frame, 
                text="↑", 
                width=30, 
                height=28,
                command=lambda idx=i: self._move_up(idx)
            )
            up_btn.pack(side="left", padx=2)
            
            down_btn = ctk.CTkButton(
                btn_frame, 
                text="↓", 
                width=30, 
                height=28,
                command=lambda idx=i: self._move_down(idx)
            )
            down_btn.pack(side="left", padx=2)
            
            info_frame = ctk.CTkFrame(frame, fg_color="transparent")
            info_frame.grid(row=0, column=1, sticky="w", padx=10)
            
            ctk.CTkLabel(
                info_frame, 
                text=f"{i+1}. {server.name}", 
                font=Fonts.BODY
            ).pack(side="left")
            
            ctk.CTkLabel(
                info_frame, 
                text=f"  ({server.address}:{server.port})", 
                font=Fonts.SMALL,
                text_color="gray"
            ).pack(side="left")
            
            self.server_frames.append(frame)
            
    def _move_up(self, index: int):
        """上移"""
        if index > 0:
            self.servers[index], self.servers[index-1] = self.servers[index-1], self.servers[index]
            self._update_list()
            
    def _move_down(self, index: int):
        """下移"""
        if index < len(self.servers) - 1:
            self.servers[index], self.servers[index+1] = self.servers[index+1], self.servers[index]
            self._update_list()
            
    def _on_complete(self):
        """完成排序"""
        for i, server in enumerate(self.servers):
            server.sort_order = i
            
        self.callback(self.servers)
        self.destroy()
