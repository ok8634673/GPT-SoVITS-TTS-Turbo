"""
主窗口
"""
import customtkinter as ctk
from tkinter import messagebox, filedialog
import asyncio
import threading
import time
from typing import Optional

from .theme import ThemeManager, Fonts
from .server_dialog import ServerDialog
from .config_dialog import ConfigDialog
from .tts_test_dialog import TTSTestDialog
from .sort_dialog import SortDialog
from ..utils.config import ConfigManager
from ..utils.logger import get_logger, get_log_history
from ..models.server_config import ServerConfig, ServerStatus, ProxyConfig, LoadBalanceStrategy

logger = get_logger()


class MainWindow(ctk.CTk):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        
        # 初始化配置
        self.config_manager = ConfigManager()
        self.proxy_config = self.config_manager.load()
        
        # 设置主题
        ThemeManager.apply_theme(self.proxy_config.ui_settings.theme)
        
        # 窗口设置
        self.title(f"GPT-SoVITS 加速服务器 v{self.proxy_config.version}")
        self.geometry(f"{self.proxy_config.ui_settings.window_width}x{self.proxy_config.ui_settings.window_height}")
        self.minsize(1000, 700)
        
        # 服务器状态
        self.servers: list[ServerConfig] = []
        self.is_running = False
        self.api_thread: Optional[threading.Thread] = None
        
        # 创建UI
        self._create_ui()
        
        # 加载服务器
        self._load_servers()
        
        # 启动时检测服务器状态
        self._check_all_servers_on_start()
        
        # 启动状态更新
        self._start_status_update()

        # 自动启动服务
        if self.proxy_config.ui_settings.auto_start_service:
            # 延迟启动，确保UI完全初始化
            self.after(1000, self._start_service)

        # 处理开机自启设置
        if self.proxy_config.ui_settings.auto_start_on_boot:
            self._set_startup()
        else:
            self._remove_startup()
        
    def _create_ui(self):
        """创建UI界面"""
        # 配置网格
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # 左侧边栏
        self._create_sidebar()
        
        # 主内容区
        self._create_main_content()
        
        # 底部状态栏
        self._create_statusbar()
        
    def _create_sidebar(self):
        """创建左侧边栏"""
        self.sidebar = ctk.CTkFrame(self, width=280, corner_radius=0)
        self.sidebar.grid(row=0, column=0, rowspan=2, sticky="nsew")
        self.sidebar.grid_propagate(False)
        
        # 标题
        title = ctk.CTkLabel(
            self.sidebar,
            text="GPT-SoVITS\n加速服务器",
            font=Fonts.TITLE,
            justify="center"
        )
        title.pack(pady=(30, 20))
        
        # 服务控制区域
        control_frame = ctk.CTkFrame(self.sidebar)
        control_frame.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(control_frame, text="服务控制", font=Fonts.SUBHEADER).pack(pady=10)
        
        self.start_btn = ctk.CTkButton(
            control_frame,
            text="▶ 启动服务",
            font=Fonts.BODY,
            height=40,
            command=self._toggle_service
        )
        self.start_btn.pack(fill="x", padx=10, pady=5)
        
        self.status_indicator = ctk.CTkLabel(
            control_frame,
            text="● 服务已停止",
            font=Fonts.BODY,
            text_color=ThemeManager.get_status_color("offline")
        )
        self.status_indicator.pack(pady=5)
        
        # 快速操作区域
        quick_frame = ctk.CTkFrame(self.sidebar)
        quick_frame.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(quick_frame, text="快速操作", font=Fonts.SUBHEADER).pack(pady=10)
        
        ctk.CTkButton(
            quick_frame,
            text="🖥️ 添加服务器",
            font=Fonts.BODY,
            command=self._add_server
        ).pack(fill="x", padx=10, pady=3)
        
        ctk.CTkButton(
            quick_frame,
            text="🧪 TTS测试",
            font=Fonts.BODY,
            command=self._open_tts_test
        ).pack(fill="x", padx=10, pady=3)
        
        ctk.CTkButton(
            quick_frame,
            text="⚙️ 配置管理",
            font=Fonts.BODY,
            command=self._open_config
        ).pack(fill="x", padx=10, pady=3)
        
        ctk.CTkButton(
            quick_frame,
            text="📋 查看日志",
            font=Fonts.BODY,
            command=self._show_logs
        ).pack(fill="x", padx=10, pady=3)
        
        # 统计信息区域
        stats_frame = ctk.CTkFrame(self.sidebar)
        stats_frame.pack(fill="x", padx=15, pady=10)
        
        ctk.CTkLabel(stats_frame, text="统计信息", font=Fonts.SUBHEADER).pack(pady=10)
        
        self.stats_labels = {}
        stats_items = [
            ("total_servers", "总服务器", "0"),
            ("online_servers", "在线服务器", "0"),
            ("total_tasks", "总任务数", "0"),
            ("pending_tasks", "待处理任务", "0")
        ]
        
        for key, label, default in stats_items:
            row = ctk.CTkFrame(stats_frame, fg_color="transparent")
            row.pack(fill="x", padx=10, pady=2)
            ctk.CTkLabel(row, text=label + ":", font=Fonts.SMALL).pack(side="left")
            self.stats_labels[key] = ctk.CTkLabel(row, text=default, font=Fonts.SMALL)
            self.stats_labels[key].pack(side="right")
            
    def _create_main_content(self):
        """创建主内容区"""
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(1, weight=1)
        
        # 服务器列表标题
        header = ctk.CTkFrame(self.main_frame)
        header.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
        header.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(header, text="🖥️ 服务器列表", font=Fonts.HEADER).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        # 操作按钮
        btn_frame = ctk.CTkFrame(header, fg_color="transparent")
        btn_frame.grid(row=0, column=1, padx=10)
        
        ctk.CTkButton(btn_frame, text="刷新", width=80, command=self._refresh_servers).pack(side="left", padx=2)
        ctk.CTkButton(btn_frame, text="测试全部", width=80, command=self._test_all_servers).pack(side="left", padx=2)
        ctk.CTkButton(btn_frame, text="排序", width=80, command=self._open_sort_dialog).pack(side="left", padx=2)
        
        # 服务器列表
        self.server_list = ctk.CTkScrollableFrame(self.main_frame)
        self.server_list.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        
        # 任务列表区域
        task_frame = ctk.CTkFrame(self.main_frame)
        task_frame.grid(row=2, column=0, sticky="ew", padx=5, pady=5)
        task_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(task_frame, text="📋 最近任务", font=Fonts.SUBHEADER).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        self.task_list = ctk.CTkScrollableFrame(task_frame, height=150)
        self.task_list.grid(row=1, column=0, sticky="ew", padx=5, pady=5)
        
    def _create_statusbar(self):
        """创建状态栏"""
        self.statusbar = ctk.CTkFrame(self, height=30, corner_radius=0)
        self.statusbar.grid(row=1, column=1, sticky="ew")
        
        self.status_label = ctk.CTkLabel(self.statusbar, text="就绪", font=Fonts.SMALL)
        self.status_label.pack(side="left", padx=10)
        
        self.version_label = ctk.CTkLabel(
            self.statusbar, 
            text=f"v{self.proxy_config.version}", 
            font=Fonts.SMALL,
            text_color="gray"
        )
        self.version_label.pack(side="right", padx=10)
        
    def _load_servers(self):
        """加载服务器列表"""
        self.servers = self.proxy_config.servers
        self._update_server_list()
        self._update_stats()
        
    def _update_server_list(self):
        """更新服务器列表显示"""
        # 清空列表
        for widget in self.server_list.winfo_children():
            widget.destroy()
            
        if not self.servers:
            empty_label = ctk.CTkLabel(
                self.server_list,
                text='暂无服务器，请点击左侧"添加服务器"按钮添加',
                font=Fonts.BODY,
                text_color="gray"
            )
            empty_label.pack(pady=50)
            return
            
        # 表头
        header = ctk.CTkFrame(self.server_list, fg_color="transparent")
        header.pack(fill="x", padx=5, pady=2)
        
        headers = [("名称", 15), ("地址", 20), ("状态", 10), ("连接数", 10), ("操作", 25)]
        for i, (text, width) in enumerate(headers):
            ctk.CTkLabel(header, text=text, font=Fonts.SMALL, width=width*10).pack(side="left", padx=2)
            
        ctk.CTkFrame(self.server_list, height=1, fg_color="gray").pack(fill="x", padx=5, pady=5)
        
        # 按排序顺序显示服务器
        sorted_servers = sorted(self.servers, key=lambda s: s.sort_order)
        for server in sorted_servers:
            self._create_server_item(server)
            
    def _create_server_item(self, server: ServerConfig):
        """创建服务器项"""
        item = ctk.CTkFrame(self.server_list)
        item.pack(fill="x", padx=5, pady=2)
        
        # 名称
        name_label = ctk.CTkLabel(item, text=server.name, font=Fonts.BODY, width=150)
        name_label.pack(side="left", padx=5)
        
        # 地址
        addr_text = f"{server.address}:{server.port}"
        addr_label = ctk.CTkLabel(item, text=addr_text, font=Fonts.SMALL, width=200)
        addr_label.pack(side="left", padx=5)
        
        # 状态
        status_color = ThemeManager.get_status_color(server.status.value)
        status_text = "● " + ("在线" if server.status == ServerStatus.ONLINE else 
                             "离线" if server.status == ServerStatus.OFFLINE else
                             "忙碌" if server.status == ServerStatus.BUSY else "错误")
        status_label = ctk.CTkLabel(item, text=status_text, font=Fonts.SMALL, 
                                     text_color=status_color, width=100)
        status_label.pack(side="left", padx=5)
        
        # 连接数
        conn_text = f"{server.current_connections}/{server.max_connections}"
        conn_label = ctk.CTkLabel(item, text=conn_text, font=Fonts.SMALL, width=100)
        conn_label.pack(side="left", padx=5)
        
        # 操作按钮
        btn_frame = ctk.CTkFrame(item, fg_color="transparent")
        btn_frame.pack(side="right", padx=5)
        
        # 启用勾选框
        enable_var = ctk.BooleanVar(value=server.enabled)
        enable_checkbox = ctk.CTkCheckBox(
            btn_frame, 
            text="启用", 
            variable=enable_var,
            command=lambda s=server, var=enable_var: self._toggle_server_enable(s, var)
        )
        enable_checkbox.pack(side="left", padx=2)
        
        ctk.CTkButton(btn_frame, text="编辑", width=60, height=28,
                     command=lambda s=server: self._edit_server(s)).pack(side="left", padx=2)
        ctk.CTkButton(btn_frame, text="复制", width=60, height=28,
                     command=lambda s=server: self._copy_server(s)).pack(side="left", padx=2)
        ctk.CTkButton(btn_frame, text="测试", width=60, height=28,
                     command=lambda s=server: self._test_server(s)).pack(side="left", padx=2)
        ctk.CTkButton(btn_frame, text="删除", width=60, height=28, fg_color="#e74c3c",
                     hover_color="#c0392b",
                     command=lambda s=server: self._delete_server(s)).pack(side="left", padx=2)
        
        item.server = server
        
    def _update_stats(self):
        """更新统计信息"""
        online_count = sum(1 for s in self.servers if s.status == ServerStatus.ONLINE)
        
        self.stats_labels["total_servers"].configure(text=str(len(self.servers)))
        self.stats_labels["online_servers"].configure(text=str(online_count))
        
    def _start_status_update(self):
        """启动状态更新定时器"""
        self._update_status()
        
    def _update_status(self):
        """更新状态"""
        if self.winfo_exists():
            # 这里可以添加更多状态更新逻辑
            self.after(5000, self._update_status)  # 每5秒更新一次
            
    def _toggle_service(self):
        """切换服务状态"""
        if self.is_running:
            self._stop_service()
        else:
            self._start_service()
            
    def _start_service(self):
        """启动服务"""
        if not self.servers:
            messagebox.showwarning("警告", "请先添加至少一个服务器")
            return
            
        try:
            # 启动API服务（在新线程中）
            self.api_thread = threading.Thread(target=self._run_api_server, daemon=True)
            self.api_thread.start()
            
            self.is_running = True
            self.start_btn.configure(text="⏹ 停止服务", fg_color="#e74c3c", hover_color="#c0392b")
            self.status_indicator.configure(
                text="● 服务运行中",
                text_color=ThemeManager.get_status_color("online")
            )
            self.status_label.configure(text=f"服务运行中 - http://{self.proxy_config.host}:{self.proxy_config.server_port}")
            
            logger.info(f"API服务已启动: http://{self.proxy_config.host}:{self.proxy_config.server_port}")
            
        except Exception as e:
            messagebox.showerror("错误", f"启动服务失败: {e}")
            logger.error(f"启动服务失败: {e}")
            
    def _stop_service(self):
        """停止服务"""
        self.is_running = False
        self.start_btn.configure(text="▶ 启动服务", fg_color="#3b82f6", hover_color="#2563eb")
        self.status_indicator.configure(
            text="● 服务已停止",
            text_color=ThemeManager.get_status_color("offline")
        )
        self.status_label.configure(text="服务已停止")
        
        logger.info("API服务已停止")
        
    def _run_api_server(self):
        """运行API服务器"""
        import uvicorn
        from ..app import create_app
        
        app = create_app()
        
        uvicorn.run(
            app,
            host=self.proxy_config.host,
            port=self.proxy_config.server_port,
            log_level="info"
        )
        
    def _add_server(self):
        """添加服务器"""
        dialog = ServerDialog(self, None, self._on_server_saved)
        dialog.grab_set()
        
    def _edit_server(self, server: ServerConfig):
        """编辑服务器"""
        dialog = ServerDialog(self, server, self._on_server_saved)
        dialog.grab_set()
        
    def _on_server_saved(self, server: ServerConfig):
        """服务器保存回调"""
        # 更新或添加服务器
        existing = False
        for i, s in enumerate(self.servers):
            if s.id == server.id:
                self.servers[i] = server
                existing = True
                break
                
        if not existing:
            self.servers.append(server)
            
        # 保存配置
        self.proxy_config.servers = self.servers
        self.config_manager.update_config(self.proxy_config)
        
        # 更新UI
        self._update_server_list()
        self._update_stats()
        
        # 通知TTS测试窗口刷新服务器列表
        if hasattr(self, 'tts_test_dialog') and self.tts_test_dialog.winfo_exists():
            self.tts_test_dialog._refresh_server_list()
        
        logger.info(f"服务器已保存: {server.name}")
        
    def _delete_server(self, server: ServerConfig):
        """删除服务器"""
        if messagebox.askyesno("确认", f"确定要删除服务器{server.name}吗？"):
            self.servers = [s for s in self.servers if s.id != server.id]
            self.proxy_config.servers = self.servers
            self.config_manager.update_config(self.proxy_config)
            
            self._update_server_list()
            self._update_stats()
            
            # 通知TTS测试窗口刷新服务器列表
            if hasattr(self, 'tts_test_dialog') and self.tts_test_dialog.winfo_exists():
                self.tts_test_dialog._refresh_server_list()
            
            logger.info(f"服务器已删除: {server.name}")
            
    def _copy_server(self, server: ServerConfig):
        """复制服务器"""
        # 创建服务器副本
        import copy
        import uuid
        new_server = copy.deepcopy(server)
        new_server.id = str(uuid.uuid4())[:8]
        new_server.name = f"{server.name} (副本)"
        
        # 添加到服务器列表
        self.servers.append(new_server)
        self.proxy_config.servers = self.servers
        self.config_manager.update_config(self.proxy_config)
        
        # 更新UI
        self._update_server_list()
        self._update_stats()
        
        # 通知TTS测试窗口刷新服务器列表
        if hasattr(self, 'tts_test_dialog') and self.tts_test_dialog.winfo_exists():
            self.tts_test_dialog._refresh_server_list()
        
        logger.info(f"服务器已复制: {new_server.name}")
        
    def _test_server(self, server: ServerConfig):
        """测试服务器"""
        self.status_label.configure(text=f"正在测试 {server.name}...")
        
        # 在新线程中测试
        def test():
            try:
                import asyncio
                from ..core.api_proxy import APIProxy
                from ..core.load_balancer import LoadBalancer
                from ..core.audio_merger import AudioMerger
                from ..core.task_queue import TaskQueue
                
                lb = LoadBalancer()
                lb.add_server(server)
                
                proxy = APIProxy(lb, TaskQueue(), AudioMerger())
                
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                result = loop.run_until_complete(proxy.test_server(server))
                loop.close()
                
                if result["success"]:
                    # 更新服务器状态
                    server.status = ServerStatus.ONLINE
                    self.after(0, lambda: messagebox.showinfo("测试结果", 
                        f"服务器: {server.name}\n状态: 连接成功\n响应时间: {result['response_time']:.2f}s"))
                    # 更新UI
                    self.after(0, self._update_server_list)
                else:
                    # 更新服务器状态
                    server.status = ServerStatus.OFFLINE
                    self.after(0, lambda: messagebox.showerror("测试结果",
                        f"服务器: {server.name}\n状态: 连接失败\n错误: {result['message']}"))
                    # 更新UI
                    self.after(0, self._update_server_list)
                    
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("错误", f"测试失败: {e}"))
            finally:
                self.after(0, lambda: self.status_label.configure(text="就绪"))
                
        threading.Thread(target=test, daemon=True).start()
        
    def _toggle_server_enable(self, server: ServerConfig, var: ctk.BooleanVar):
        """切换服务器启用状态"""
        # 更新服务器的enabled属性
        server.enabled = var.get()
        
        # 保存配置
        self.proxy_config.servers = self.servers
        self.config_manager.update_config(self.proxy_config)
        
        # 更新UI
        self._update_server_list()
        self._update_stats()
        
        # 通知TTS测试窗口刷新服务器列表
        if hasattr(self, 'tts_test_dialog') and self.tts_test_dialog.winfo_exists():
            self.tts_test_dialog._refresh_server_list()
        
        logger.info(f"服务器 {server.name} 启用状态已更新为: {server.enabled}")
        
    def _open_sort_dialog(self):
        """打开排序对话框"""
        if not self.servers:
            messagebox.showinfo("提示", "没有服务器需要排序")
            return
            
        SortDialog(self, self.servers, self._on_sort_completed)
        
    def _on_sort_completed(self, sorted_servers: list):
        """排序完成回调"""
        self.servers = sorted_servers
        self.proxy_config.servers = self.servers
        self.config_manager.update_config(self.proxy_config)
        
        self._update_server_list()
        logger.info("服务器排序已更新")
        
    def _test_all_servers(self):
        """测试所有服务器"""
        self._check_all_servers(show_result=True)
        
    def _check_all_servers_on_start(self):
        """启动时检查所有服务器状态"""
        self._check_all_servers(show_result=False)
        
    def _check_all_servers(self, show_result: bool = True):
        """检查所有服务器状态"""
        if not self.servers:
            if show_result:
                messagebox.showinfo("提示", "没有服务器需要测试")
            return
            
        self.status_label.configure(text="正在检测服务器状态...")
        
        def check_all():
            results = []
            for server in self.servers:
                try:
                    import asyncio
                    from ..core.api_proxy import APIProxy
                    from ..core.load_balancer import LoadBalancer
                    from ..core.audio_merger import AudioMerger
                    from ..core.task_queue import TaskQueue
                    
                    lb = LoadBalancer()
                    lb.add_server(server)
                    
                    proxy = APIProxy(lb, TaskQueue(), AudioMerger())
                    
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(proxy.test_server(server))
                    loop.close()
                    
                    # 更新服务器状态
                    if result["success"]:
                        server.status = ServerStatus.ONLINE
                    else:
                        server.status = ServerStatus.OFFLINE
                    
                    results.append((server.name, result["success"], result.get("message", "")))
                except Exception as e:
                    server.status = ServerStatus.OFFLINE
                    results.append((server.name, False, str(e)))
                    
            # 更新UI
            self.after(0, self._update_server_list)
            self.after(0, self._update_stats)
            
            # 显示结果
            if show_result:
                msg = "测试结果:\n\n"
                for name, success, message in results:
                    status = "✓ 成功" if success else "✗ 失败"
                    msg += f"{name}: {status}\n"
                    if not success:
                        msg += f"  错误: {message}\n"
                        
                self.after(0, lambda: messagebox.showinfo("批量测试", msg))
            
            self.after(0, lambda: self.status_label.configure(text="就绪"))
            
        threading.Thread(target=check_all, daemon=True).start()
        
    def _refresh_servers(self):
        """刷新服务器列表"""
        self._load_servers()
        self.status_label.configure(text="服务器列表已刷新")
        
    def _open_tts_test(self):
        """打开TTS测试对话框"""
        if not self.is_running:
            messagebox.showwarning("警告", "请先启动服务")
            return
            
        dialog = TTSTestDialog(self, self.proxy_config)
        dialog.grab_set()
        
        # 保存对话框引用，以便后续通知
        self.tts_test_dialog = dialog
        
    def _open_config(self):
        """打开配置管理对话框"""
        dialog = ConfigDialog(self, self.config_manager, self._on_config_saved)
        dialog.grab_set()
        
    def _on_config_saved(self):
        """配置保存回调"""
        self.proxy_config = self.config_manager.load()
        self._load_servers()
        logger.info("配置已重新加载")
        
    def _show_logs(self):
        """显示日志"""
        logs = get_log_history(count=50)
        
        log_window = ctk.CTkToplevel(self)
        log_window.title("系统日志")
        log_window.geometry("800x500")
        
        text = ctk.CTkTextbox(log_window, font=Fonts.MONO)
        text.pack(fill="both", expand=True, padx=10, pady=10)
        
        for log in logs:
            text.insert("end", f"[{log['time']}] [{log['level']}] {log['message']}\n")
            
        text.configure(state="disabled")

    def _set_startup(self):
        """设置开机自启"""
        try:
            import os
            import winshell
            from win32com.client import Dispatch
            
            # 获取启动文件夹路径
            startup_folder = winshell.startup()
            
            # 创建快捷方式
            shortcut_path = os.path.join(startup_folder, "GPT-SoVITS-Proxy.lnk")
            
            # 获取当前可执行文件路径
            import sys
            if getattr(sys, 'frozen', False):
                # 打包后的情况
                exe_path = sys.executable
            else:
                # 开发环境
                exe_path = os.path.abspath(sys.argv[0])
            
            # 创建快捷方式
            shell = Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = exe_path
            shortcut.WorkingDirectory = os.path.dirname(exe_path)
            shortcut.IconLocation = exe_path
            shortcut.save()
            
            logger.info("已设置开机自启")
            
        except Exception as e:
            logger.error(f"设置开机自启失败: {e}")

    def _remove_startup(self):
        """移除开机自启"""
        try:
            import os
            import winshell
            
            # 获取启动文件夹路径
            startup_folder = winshell.startup()
            
            # 快捷方式路径
            shortcut_path = os.path.join(startup_folder, "GPT-SoVITS-Proxy.lnk")
            
            # 删除快捷方式
            if os.path.exists(shortcut_path):
                os.remove(shortcut_path)
                logger.info("已移除开机自启")
            
        except Exception as e:
            logger.error(f"移除开机自启失败: {e}")
        
    def run(self):
        """运行应用"""
        self.mainloop()
